# Source this file from Bash or Zsh. A shell function is needed to update ENV.
claude() {
    command cc-account terminal "$@"
}
cc-account() {
    case "${1:-list}" in
        use|add|login)
            if [ "$#" -ne 2 ]; then
                printf 'Usage: cc-account %s <name>\n' "$1" >&2
                return 1
            fi
            if [ "$1" = login ] && [ "$2" = auto ]; then
                printf '%s\n' 'Log in to a named profile, not auto.' >&2
                return 1
            fi
            local cc_selected_path
            if [ "$1" = add ]; then
                command cc-account add "$2" || return
            fi
            cc_selected_path=$(command cc-account env "$2") || return
            if [ -n "$cc_selected_path" ]; then
                export CLAUDE_CONFIG_DIR="$cc_selected_path"
            else
                unset CLAUDE_CONFIG_DIR
            fi
            if [ "$1" = login ]; then
                command cc-account login "$2"
            else
                printf "Selected '%s' for new Claude processes in this terminal.\n" "$2"
            fi
            ;;
        *) command cc-account "$@" ;;
    esac
}
