#!/usr/bin/env python3
"""Portable Linux account management; shared files never include credentials."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

import router

DIRECTORIES = ('projects', 'file-history', 'plans', 'tasks', 'todos', 'paste-cache',
               'skills', 'commands', 'agents', 'rules', 'hooks', 'plugins',
               'workflows', 'output-styles')
FILES = ('settings.json', 'history.jsonl', 'CLAUDE.md', 'keybindings.json')
SEED_KEYS = ('projects', 'mcpServers', 'hasCompletedOnboarding', 'lastOnboardingVersion',
             'theme', 'editorMode', 'autoConnectIde', 'autoInstallIdeExtension', 'externalEditorContext')
OVERRIDES = ('ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN',
             'ANTHROPIC_PROFILE', 'ANTHROPIC_FEDERATION_RULE_ID', 'CLAUDE_CODE_USE_BEDROCK',
             'CLAUDE_CODE_USE_VERTEX', 'CLAUDE_CODE_USE_FOUNDRY')


def context():
    root = router.root_path()
    manager = router.load(root / 'manager.json')
    if not manager:
        raise ValueError('Account manager is not initialized. Run install.sh first.')
    return root, manager


def path_for(root, manager, name):
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,63}', name):
        raise ValueError('Use 1-64 lowercase letters, digits, underscores or hyphens.')
    if name == 'default':
        return Path(manager.get('defaultConfigDirectory') or manager['sharedDirectory'])
    if name == 'auto':
        return Path(router.read_config(root)['fixedConfigDirectory'])
    return root / 'profiles' / name


def guard_overrides():
    for key in OVERRIDES:
        if os.environ.get(key):
            raise ValueError(key + ' can override this account. Unset it deliberately first.')


def add(root, manager, name):
    guard_overrides()
    path = path_for(root, manager, name)
    if name in ('default', 'auto'):
        raise ValueError('default and auto are reserved selectors.')
    with router.router_lock(root):
        if os.path.lexists(path):
            raise ValueError('Profile already exists: ' + name)
        shared = Path(manager['sharedDirectory'])
        staging = path.with_name('.new-' + uuid.uuid4().hex)
        staging.mkdir(mode=0o700)
        try:
            for entry in DIRECTORIES:
                target = shared / entry
                target.mkdir(exist_ok=True)
                (staging / entry).symlink_to(target, target_is_directory=True)
            for entry in FILES:
                target = shared / entry
                if target.is_file():
                    (staging / entry).symlink_to(target)
            source = (Path(manager['defaultConfigDirectory']) / '.claude.json'
                      if manager.get('defaultConfigDirectory') else Path.home() / '.claude.json')
            original = router.load(source, {})
            router.save(staging / '.claude.json', {key: original[key] for key in SEED_KEYS if key in original})
            staging.rename(path)
        except Exception:
            shutil.rmtree(staging)
            raise
    print('Created ' + name + '. Run cc-account login ' + name + ' to log in once.')


def selected_env(root, manager, name):
    guard_overrides()
    path = path_for(root, manager, name)
    if not path.is_dir():
        raise ValueError('Unknown profile: ' + name)
    return str(path) if name != 'default' or manager.get('defaultConfigDirectory') else None


def sync_default_after_login(root, manager):
    # An ENV-unset login updates ~/.claude.json, while VS Code's explicit ENV
    # reads ~/.claude/.claude.json. They represent the same default account.
    if manager.get('defaultConfigDirectory'):
        return
    original = router.load(Path.home() / '.claude.json')
    if not isinstance(original, dict):
        return
    with router.router_lock(root):
        path = Path(manager['sharedDirectory']) / '.claude.json'
        existing = router.load(path, {})
        updated = dict(existing)
        for key in SEED_KEYS:
            if key in original and key not in updated:
                updated[key] = original[key]
        for key in ('oauthAccount', 'userID'):
            if key in original:
                updated[key] = original[key]
        if updated != existing or not path.exists():
            router.save(path, updated)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', nargs='?', default='list',
                        choices=['add', 'use', 'env', 'list', 'login', 'status', 'check', 'remove', 'run', 'help'])
    parser.add_argument('name', nargs='?')
    parser.add_argument('claude_args', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    root, manager = context()
    if args.action == 'help':
        print('''cc-account add <name>     Create a profile; then login once.
cc-account login <name>   Open Claude browser authentication for that profile.
cc-account use <name>     Select a profile in Bash/Zsh/PowerShell with shell integration loaded.
cc-account use auto       Follow the fixed VS Code account path.
cc-account run <name> [Claude arguments]   Launch Claude without changing the parent shell.
cc-account list           List profiles; cc-auto status shows the automatic selection.
cc-account status        Show authentication status for this terminal.
cc-account check <name>  Verify shared links.
cc-account remove <name> Remove an inactive profile and saved login.
cc-auto priority [names...]   View or set account order.
cc-auto check|status|start|stop|restart|logs
After selecting, use claude --continue or claude --resume <session-id>.''')
        return 0
    if args.action == 'list':
        names = ['default', 'auto'] + sorted(p.name for p in (root / 'profiles').iterdir()
                                             if p.is_dir() and not p.name.startswith('.'))
        current = os.environ.get('CLAUDE_CONFIG_DIR')
        for name in names:
            path = path_for(root, manager, name)
            selected = (current == str(path) if name != 'default' or manager.get('defaultConfigDirectory') else not current)
            print(f"{'*' if selected else ' '} {name}: login={'stored' if (path / '.credentials.json').is_file() else 'missing'}; {path}")
        return 0
    if args.action == 'status':
        return subprocess.call(['claude', 'auth', 'status'])
    if not args.name:
        raise ValueError('Usage: cc-account ' + args.action + ' <name>')
    if args.claude_args and args.action != 'run':
        raise ValueError('Unexpected extra arguments.')
    if args.action == 'add':
        add(root, manager, args.name)
        return 0
    if args.action == 'remove':
        router.remove_profile(root, args.name)
        return 0
    if args.action == 'check':
        path = path_for(root, manager, args.name)
        if not path.is_dir():
            raise ValueError('Unknown profile: ' + args.name)
        if args.name == 'default':
            print('default uses the existing shared data directly.')
            return 0
        shared = Path(manager['sharedDirectory'])
        good = True
        for entry in DIRECTORIES + FILES:
            target = shared / entry
            if entry in FILES and not target.is_file():
                continue
            link = path / entry
            valid = link.is_symlink() and link.resolve() == target.resolve() and target.exists()
            good = good and valid
            print(entry + ': Shared=' + str(valid))
        return 0 if good else 1
    if args.action == 'login' and args.name == 'auto':
        raise ValueError('Log in to a named profile instead of auto.')
    value = selected_env(root, manager, args.name)
    if args.action == 'env':
        print(value or '')
        return 0
    if args.action == 'use':
        raise ValueError('Load shell integration first: source ~/.config/claude-accounts/accounts.sh; or use cc-account run <name>.')
    env = dict(os.environ)
    if value:
        env['CLAUDE_CONFIG_DIR'] = value
    else:
        env.pop('CLAUDE_CONFIG_DIR', None)
    command = ['claude'] + (['auth', 'login'] if args.action == 'login' else args.claude_args)
    result = subprocess.call(command, env=env)
    if result == 0 and args.action == 'login' and args.name == 'default':
        sync_default_after_login(root, manager)
    return result


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, json.JSONDecodeError) as error:
        print('cc-account:', str(error), file=sys.stderr)
        sys.exit(1)
