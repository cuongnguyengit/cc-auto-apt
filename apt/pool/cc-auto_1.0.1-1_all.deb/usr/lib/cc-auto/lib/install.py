#!/usr/bin/env python3
"""Install without exporting any source-machine credentials or user state."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

import accounts
import router


def atomic_text(path, text, mode=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    # Follow existing user-managed symlinks, preserving their destination.
    if path.is_symlink():
        path = path.resolve()
    if mode is None:
        mode = path.stat().st_mode & 0o777 if path.exists() else 0o600
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(text)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def jsonc_tokens(text):
    tokens = []
    i = 0
    while i < len(text):
        if text[i].isspace() or text[i] == '\ufeff':
            i += 1
        elif text.startswith('//', i):
            end = text.find('\n', i)
            i = len(text) if end < 0 else end
        elif text.startswith('/*', i):
            end = text.find('*/', i + 2)
            if end < 0:
                raise ValueError('Unclosed JSONC comment')
            i = end + 2
        elif text[i] == '"':
            start = i
            i += 1
            while i < len(text):
                if text[i] == '\\':
                    i += 2
                elif text[i] == '"':
                    i += 1
                    break
                else:
                    i += 1
            tokens.append((text[start:i], start, i))
        elif text[i] in '{}[]:,':
            tokens.append((text[i], i, i + 1))
            i += 1
        else:
            start = i
            while i < len(text) and not text[i].isspace() and text[i] not in '{}[]:,/':
                i += 1
            if i == start:
                raise ValueError('Invalid JSONC token')
            tokens.append((text[start:i], start, i))
    return tokens


def vscode_settings(text, fixed):
    """Change one top-level JSONC value, retaining all other text and comments."""
    tokens = jsonc_tokens(text)
    cleaned = ''.join(token[0] for i, token in enumerate(tokens)
                      if not (token[0] == ',' and i + 1 < len(tokens) and tokens[i + 1][0] in (']', '}')))
    data = json.loads(cleaned)
    if not isinstance(data, dict):
        raise ValueError('VS Code settings must be a JSON object')
    key = 'claudeCode.environmentVariables'
    entries = data.get(key, [])
    if not isinstance(entries, list) or any(not isinstance(entry, dict) for entry in entries):
        raise ValueError(key + ' must be an array of objects')
    updated = [entry for entry in entries if entry.get('name') != 'CLAUDE_CONFIG_DIR']
    updated.append({'name': 'CLAUDE_CONFIG_DIR', 'value': str(fixed)})
    if entries == updated:
        return text
    value = json.dumps(updated, ensure_ascii=False, indent=2).replace('\n', '\n  ')
    index = 1
    last_value_end = None
    while index < len(tokens) - 1:
        if tokens[index][0] == ',':
            index += 1
            continue
        name = json.loads(tokens[index][0])
        if tokens[index + 1][0] != ':':
            raise ValueError('Invalid JSONC property')
        begin = index + 2
        end = begin
        if tokens[begin][0] in ('{', '['):
            depth = 1
            while depth:
                end += 1
                if tokens[end][0] in ('{', '['):
                    depth += 1
                elif tokens[end][0] in ('}', ']'):
                    depth -= 1
        if name == key:
            return text[:tokens[begin][1]] + value + text[tokens[end][2]:]
        last_value_end = tokens[end][2]
        index = end + 1
    closing = tokens[-1][1]
    prefix = text[:closing]
    if last_value_end is not None and tokens[-2][0] != ',':
        prefix = prefix[:last_value_end] + ',' + prefix[last_value_end:]
    return prefix.rstrip() + '\n  ' + json.dumps(key) + ': ' + value + '\n' + text[closing:]


def systemd_quote(text):
    return '"' + str(text).replace('\\', '\\\\').replace('"', '\\"').replace('%', '%%') + '"'


def install(args):
    home = Path(args.target_home).expanduser().absolute() if args.target_home else Path.home()
    root = Path(os.environ.get('CLAUDE_ACCOUNTS_ROOT', home / '.claude-accounts')).absolute()
    code = home / '.config/claude-accounts'
    backend = Path(__file__).resolve().parent if args.system_package else code
    binary = home / '.local/bin'
    fixed = home / '.claude-vscode'
    manager = router.load(root / 'manager.json')
    original_env = os.environ.get('CLAUDE_CONFIG_DIR')
    if not manager:
        default = str(Path(original_env).expanduser().absolute()) if original_env else None
        if default == str(fixed):
            raise ValueError('Unset CLAUDE_CONFIG_DIR for the first install; it already points at .claude-vscode.')
        manager = {'version': 1, 'sharedDirectory': default or str(home / '.claude'),
                   'defaultConfigDirectory': default}
    shared = Path(manager['sharedDirectory'])
    config = router.read_config(root) if (root / 'router.json').exists() else {
        'version': 1, 'fixedConfigDirectory': str(fixed), 'priority': ['default'],
        'autoDiscoverProfiles': True, 'intervalSeconds': 60, 'candidateIntervalSeconds': 180,
        'candidateStaggerSeconds': 15, 'switchAtPercent': 95,
        'returnBelowPercent': 90, 'accountThresholds': {},
        'maxObservationAgeSeconds': 240, 'model': args.model or 'opus',
    }
    if args.model:
        config['model'] = args.model
    fixed = Path(config['fixedConfigDirectory'])
    if fixed == shared or shared in fixed.parents or fixed in shared.parents:
        raise ValueError('The fixed config path and shared directory must be separate.')
    if os.path.lexists(fixed) and not fixed.is_symlink():
        raise ValueError(str(fixed) + ' is a real file/directory. Back it up or choose another path before installing.')
    if fixed.is_symlink():
        allowed = {shared.resolve()} | {p.resolve() for p in (root / 'profiles').glob('*') if p.is_dir()}
        if fixed.resolve() not in allowed:
            raise ValueError('The fixed path is an unrelated symlink; refusing to overwrite it.')
    # Parse settings before making changes, so malformed JSONC cannot leave a partial setup.
    changes = []
    if not args.no_vscode:
        candidates = [home / '.config/Code/User/settings.json',
                      home / '.vscode-server/data/Machine/settings.json']
        candidates += [p for p in (home / '.config/Code - Insiders/User/settings.json',
                                   home / '.vscode-server-insiders/data/Machine/settings.json') if p.exists()]
        for path in candidates:
            original = path.read_text() if path.exists() else '{}\n'
            updated = vscode_settings(original, fixed)
            if updated != original:
                changes.append((path, updated))
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    (root / 'profiles').mkdir(exist_ok=True, mode=0o700)
    shared.mkdir(parents=True, exist_ok=True, mode=0o700)
    code.mkdir(parents=True, exist_ok=True)
    binary.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup = root / 'install-backups' / stamp

    def write(path, text, mode=None):
        if path.exists() and path.read_text() == text:
            return
        if path.exists():
            backup.mkdir(parents=True, exist_ok=True, mode=0o700)
            backup_path = backup / (str(path).replace('/', '_'))
            shutil.copyfile(path, backup_path)
            backup_path.chmod(0o600)
        atomic_text(path, text, mode)

    with router.router_lock(root):
        for entry in accounts.DIRECTORIES:
            (shared / entry).mkdir(exist_ok=True)
        for name, initial in (('settings.json', '{}\n'), ('history.jsonl', '')):
            path = shared / name
            if not path.exists():
                atomic_text(path, initial)
        # Explicit ENV uses <config-dir>/.claude.json. Preserve legacy default setup.
        legacy = home / '.claude.json'
        explicit = shared / '.claude.json'
        if not manager.get('defaultConfigDirectory') and legacy.is_file():
            old = router.load(legacy, {})
            existing = router.load(explicit)
            if existing is None:
                write(explicit, json.dumps(old, indent=2) + '\n', 0o600)
            else:
                seeded = dict(existing)
                for key in accounts.SEED_KEYS + ('oauthAccount', 'userID'):
                    if key in old and key not in seeded:
                        seeded[key] = old[key]
                if seeded != existing:
                    write(explicit, json.dumps(seeded, indent=2) + '\n', 0o600)
        source = Path(__file__).parent
        for name in ('router.py', 'accounts.py', 'accounts.sh', 'accounts.ps1'):
            write(code / name, (source / name).read_text(), 0o644)
        for command, script in (('cc-auto', 'router.py'), ('cc-account', 'accounts.py')):
            wrapper = '#!/bin/sh\nexec ' + shlex.quote(sys.executable) + ' ' + shlex.quote(str(backend / script)) + ' "$@"\n'
            write(binary / command, wrapper, 0o755)
        router.save(root / 'manager.json', manager)
        router.save(root / 'router.json', config)
        if not fixed.is_symlink():
            fixed.parent.mkdir(parents=True, exist_ok=True)
            router.switch_pointer(fixed, shared.resolve(), manager)
    unit = '''[Unit]
Description=Select Claude Code accounts by usage for VS Code
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={python} {router} daemon
Environment={root_env}
Restart=on-failure
RestartSec=10
UMask=0077
NoNewPrivileges=yes
TimeoutStopSec=25

[Install]
WantedBy=default.target
'''.format(python=systemd_quote(sys.executable), router=systemd_quote(backend / 'router.py'),
           root_env=systemd_quote('CLAUDE_ACCOUNTS_ROOT=' + str(root)))
    write(home / '.config/systemd/user' / router.SERVICE, unit, 0o644)
    for path, updated in changes:
        write(path, updated)
    if not args.no_shell:
        shell_block = '''# >>> claude-accounts >>>
export PATH="$HOME/.local/bin:$PATH"
. "$HOME/.config/claude-accounts/accounts.sh"
# <<< claude-accounts <<<'''
        ps_block = '''# >>> claude-accounts >>>
if (($env:PATH -split [IO.Path]::PathSeparator) -notcontains "$HOME/.local/bin") { $env:PATH = "$HOME/.local/bin" + [IO.Path]::PathSeparator + $env:PATH }
. "$HOME/.config/claude-accounts/accounts.ps1"
# <<< claude-accounts <<<'''
        for path, block in ((home / '.bashrc', shell_block), (home / '.zshrc', shell_block),
                            (home / '.config/powershell/Microsoft.PowerShell_profile.ps1', ps_block)):
            current = path.read_text() if path.exists() else ''
            pattern = r'(?ms)^# >>> claude-accounts >>>\n.*?^# <<< claude-accounts <<<\n?'
            current = re.sub(pattern, '', current)
            # Earlier installations used this two-line PowerShell snippet.
            if path.suffix == '.ps1':
                current = re.sub(r"(?m)^# Claude Code account profiles\.\n\. \(Join-Path \$HOME '\.config/claude-accounts/accounts\.ps1'\)\n?", '', current)
            write(path, current.rstrip('\n') + '\n\n' + block + '\n')
    readme = Path(__file__).parent.parent / 'README.md'
    write(root / 'README.md', readme.read_text(), 0o644)
    print('Installed cc-account and cc-auto in ' + str(binary))
    print('Fixed CLAUDE_CONFIG_DIR: ' + str(fixed))
    print('Shared projects/sessions: ' + str(shared))
    if not args.no_service:
        if args.target_home and home != Path.home():
            print('Service not started for an alternate target home. Run install.sh there without --target-home.')
        elif not shutil.which('systemctl'):
            print('systemd is unavailable. Start manually: ' + str(binary / 'cc-auto') + ' daemon')
        else:
            commands = (['systemctl', '--user', 'daemon-reload'],
                        ['systemctl', '--user', 'enable', router.SERVICE],
                        ['systemctl', '--user', 'restart', router.SERVICE])
            for command in commands:
                result = subprocess.run(command, capture_output=True, text=True)
                if result.returncode:
                    print('Service could not start in this environment. Start later with: cc-auto start')
                    print('Or run in the foreground: cc-auto daemon')
                    break
            else:
                print('Automatic account selection service: enabled and running.')
    print('Open a new terminal (or source ~/.bashrc). Reload VS Code once after the first installation.')
    print('Add accounts: cc-account add work; cc-account login work')
    if not shutil.which('claude'):
        print('Claude Code CLI is not on PATH yet. Install it before running cc-account login.')
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-service', action='store_true', help='install the unit without enabling/starting it')
    parser.add_argument('--no-vscode', action='store_true', help='leave VS Code settings unchanged')
    parser.add_argument('--no-shell', action='store_true', help='leave shell profiles unchanged')
    parser.add_argument('--model', choices=('opus', 'sonnet', 'haiku'), help='model-specific quota (default opus; preserve on upgrade)')
    parser.add_argument('--target-home', help='stage an installation for another home directory; does not start the service')
    parser.add_argument('--system-package', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if sys.platform != 'linux' or sys.version_info < (3, 9):
        parser.error('Requires Linux and Python 3.9+.')
    return install(args)


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, json.JSONDecodeError) as error:
        print('install:', str(error), file=sys.stderr)
        sys.exit(1)
