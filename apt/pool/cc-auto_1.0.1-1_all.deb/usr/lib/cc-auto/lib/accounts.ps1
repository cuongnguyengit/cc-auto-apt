# Dot-source this file. Selection changes only the current PowerShell environment.
function Get-CCAccountContext {
    $root = if ($env:CLAUDE_ACCOUNTS_ROOT) {
        [IO.Path]::GetFullPath($env:CLAUDE_ACCOUNTS_ROOT)
    } else { Join-Path $HOME '.claude-accounts' }
    $configPath = Join-Path $root 'manager.json'
    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        throw "Account manager is not initialized: $configPath"
    }
    $config = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
    [pscustomobject]@{ Root = $root; Shared = $config.sharedDirectory; DefaultConfig = $config.defaultConfigDirectory }
}

function Get-CCSharedDirectories {
    @('projects', 'file-history', 'plans', 'tasks', 'todos', 'paste-cache',
      'skills', 'commands', 'agents', 'rules', 'hooks', 'plugins', 'workflows', 'output-styles')
}

function Get-CCSharedFiles {
    @('settings.json', 'history.jsonl', 'CLAUDE.md', 'keybindings.json')
}

function Get-CCAccountPath {
    param([Parameter(Mandatory)][string]$Name, $Context)
    if ($Name -cnotmatch '^[a-z0-9][a-z0-9_-]{0,63}$') {
        throw 'Use 1-64 lowercase letters, digits, underscores or hyphens; start with a letter or digit.'
    }
    if ($Name -eq 'default') { return $Context.Shared }
    if ($Name -eq 'auto') {
        $routerPath = Join-Path $Context.Root 'router.json'
        if (-not (Test-Path -LiteralPath $routerPath -PathType Leaf)) { throw 'Automatic selection is not installed.' }
        return (Get-Content -LiteralPath $routerPath -Raw | ConvertFrom-Json).fixedConfigDirectory
    }
    Join-Path (Join-Path $Context.Root 'profiles') $Name
}

function Set-CCPrivateMode {
    param([string]$Path, [switch]$Directory)
    if (-not $IsWindows) {
        $mode = if ($Directory) {
            [IO.UnixFileMode]::UserRead -bor [IO.UnixFileMode]::UserWrite -bor [IO.UnixFileMode]::UserExecute
        } else { [IO.UnixFileMode]::UserRead -bor [IO.UnixFileMode]::UserWrite }
        [IO.File]::SetUnixFileMode($Path, $mode)
    }
}

function Test-CCLink {
    param([string]$Path, [string]$Target)
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
    if (-not $item -or $item.LinkType -ne 'SymbolicLink') { return $false }
    $resolved = $item.ResolveLinkTarget($false)
    return $resolved -and ([IO.Path]::GetFullPath($resolved.FullName) -ceq [IO.Path]::GetFullPath($Target)) -and (Test-Path -LiteralPath $Target)
}

function cc-account {
    [CmdletBinding()]
    param(
        [Parameter(Position = 0)][ValidateSet('add', 'use', 'list', 'login', 'status', 'check', 'remove', 'help')]
        [string]$Action = 'list',
        [Parameter(Position = 1)][string]$Name
    )
    $ctx = Get-CCAccountContext
    if ($Action -eq 'help') {
        @'
cc-account add <name>    Create and select a new profile; then run cc-account login <name>.
cc-account use <name>    Select a profile for future Claude launches in this terminal.
cc-account use default   Return to the existing account, preserving its original config path.
cc-account use auto      Use the same automatically selected account path as VS Code.
cc-account list          List profiles and the selected config directory.
cc-account login <name>  Select a profile and run the browser authentication flow.
cc-account status        Show Claude's authentication status for the selected profile.
cc-account check <name>  Verify the shared links for a profile (no changes).
cc-account remove <name> Remove an inactive profile and saved login; shared data is preserved.

After switching, run claude --resume <session-id> or claude --continue.
Selection does not change a running Claude process or persist to other terminals.
'@
        return
    }
    if ($Action -eq 'status') {
        & (Get-Command claude -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source auth status
        return
    }
    if ($Action -eq 'list') {
        $selected = $env:CLAUDE_CONFIG_DIR
        $defaultActive = if ($ctx.DefaultConfig) { $selected -ceq $ctx.DefaultConfig } else { -not $selected }
        [pscustomobject]@{
            Name = 'default'; Active = $defaultActive
            StoredLogin = Test-Path -LiteralPath (Join-Path $ctx.Shared '.credentials.json')
            ConfigDirectory = if ($ctx.DefaultConfig) { $ctx.DefaultConfig } else { "$($ctx.Shared) (ENV unset)" }
        }
        if (Test-Path -LiteralPath (Join-Path $ctx.Root 'router.json') -PathType Leaf) {
            $autoPath = Get-CCAccountPath -Name auto -Context $ctx
            [pscustomobject]@{
                Name = 'auto'; Active = $selected -ceq $autoPath
                StoredLogin = Test-Path -LiteralPath (Join-Path $autoPath '.credentials.json')
                ConfigDirectory = $autoPath
            }
        }
        foreach ($profile in Get-ChildItem -LiteralPath (Join-Path $ctx.Root 'profiles') -Directory | Sort-Object Name) {
            if ($profile.Name.StartsWith('.')) { continue }
            [pscustomobject]@{
                Name = $profile.Name; Active = $selected -and ([IO.Path]::GetFullPath($selected) -ceq $profile.FullName)
                StoredLogin = Test-Path -LiteralPath (Join-Path $profile.FullName '.credentials.json')
                ConfigDirectory = $profile.FullName
            }
        }
        return
    }
    if (-not $Name) { throw "Usage: cc-account $Action <name>" }
    $path = Get-CCAccountPath -Name $Name -Context $ctx
    if ($Action -eq 'remove') {
        & (Get-Command python3 -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source (Join-Path $PSScriptRoot 'router.py') remove $Name
        if ($LASTEXITCODE -ne 0) { throw "Could not remove profile '$Name'; see the reason above." }
        return
    }
    if ($Action -eq 'login' -and $Name -eq 'auto') {
        throw 'Log in to a named account profile instead of the moving auto selector.'
    }
    if ($Action -in @('add', 'use', 'login')) {
        # Leave overriding credentials untouched, but refuse an ambiguous selection.
        foreach ($key in @('ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'CLAUDE_CODE_OAUTH_TOKEN', 'ANTHROPIC_PROFILE',
                           'ANTHROPIC_FEDERATION_RULE_ID', 'CLAUDE_CODE_USE_BEDROCK', 'CLAUDE_CODE_USE_VERTEX', 'CLAUDE_CODE_USE_FOUNDRY')) {
            if ([Environment]::GetEnvironmentVariable($key)) {
                throw "$key is set and can override the account. Unset it deliberately, then select the profile again."
            }
        }
    }
    if ($Action -eq 'add') {
        if ($Name -in @('default', 'auto')) { throw 'default and auto are reserved account selectors.' }
        if (Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue) { throw "Profile already exists: $Name" }
        $staging = Join-Path (Join-Path $ctx.Root 'profiles') ('.new-' + [guid]::NewGuid().ToString('N'))
        $null = New-Item -ItemType Directory -Path $staging -ErrorAction Stop
        Set-CCPrivateMode -Path $staging -Directory
        try {
            foreach ($entry in Get-CCSharedDirectories) {
                $target = Join-Path $ctx.Shared $entry
                if (-not (Test-Path -LiteralPath $target)) {
                    $null = New-Item -ItemType Directory -Path $target -ErrorAction Stop
                }
                if (-not (Test-Path -LiteralPath $target -PathType Container)) { throw "Expected directory: $target" }
                $null = New-Item -ItemType SymbolicLink -Path (Join-Path $staging $entry) -Target $target -ErrorAction Stop
            }
            foreach ($entry in Get-CCSharedFiles) {
                $target = Join-Path $ctx.Shared $entry
                if (Test-Path -LiteralPath $target -PathType Leaf) {
                    $null = New-Item -ItemType SymbolicLink -Path (Join-Path $staging $entry) -Target $target -ErrorAction Stop
                }
            }
            # Seed project trust/MCP/preferences only. Never copy identity, credentials,
            # account caches, remote policy, or usage data from the existing account.
            $source = if ($ctx.DefaultConfig) { Join-Path $ctx.DefaultConfig '.claude.json' } else { Join-Path $HOME '.claude.json' }
            if (Test-Path -LiteralPath $source -PathType Leaf) {
                $original = Get-Content -LiteralPath $source -Raw | ConvertFrom-Json -AsHashtable
                $seed = @{}
                foreach ($key in @('projects', 'mcpServers', 'hasCompletedOnboarding', 'lastOnboardingVersion',
                                   'theme', 'editorMode', 'autoConnectIde', 'autoInstallIdeExtension', 'externalEditorContext')) {
                    if ($original.ContainsKey($key)) { $seed[$key] = $original[$key] }
                }
                $seedPath = Join-Path $staging '.claude.json'
                $seed | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $seedPath -Encoding utf8 -ErrorAction Stop
                Set-CCPrivateMode -Path $seedPath
            }
            Move-Item -LiteralPath $staging -Destination $path -ErrorAction Stop
        } catch {
            # Only our unpublished staging directory is eligible for cleanup.
            Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
            throw
        }
        $env:CLAUDE_CONFIG_DIR = $path
        Write-Host "Created and selected '$Name'. Run cc-account login $Name to log in once."
        Write-Host "Config: $path"
        return
    }
    if (-not (Test-Path -LiteralPath $path -PathType Container)) { throw "Unknown profile '$Name'. Run cc-account add $Name first." }
    if ($Action -eq 'check') {
        if ($Name -eq 'default') { Write-Host 'default uses the existing data directly.'; return }
        foreach ($entry in Get-CCSharedDirectories) {
            [pscustomobject]@{ Entry = $entry; Shared = Test-CCLink -Path (Join-Path $path $entry) -Target (Join-Path $ctx.Shared $entry) }
        }
        foreach ($entry in Get-CCSharedFiles) {
            if (Test-Path -LiteralPath (Join-Path $ctx.Shared $entry) -PathType Leaf) {
                [pscustomobject]@{ Entry = $entry; Shared = Test-CCLink -Path (Join-Path $path $entry) -Target (Join-Path $ctx.Shared $entry) }
            }
        }
        return
    }
    if ($Name -eq 'default') {
        if ($ctx.DefaultConfig) { $env:CLAUDE_CONFIG_DIR = $ctx.DefaultConfig }
        else { Remove-Item Env:CLAUDE_CONFIG_DIR -ErrorAction SilentlyContinue }
    } else { $env:CLAUDE_CONFIG_DIR = $path }
    Write-Host "Selected '$Name' for new Claude processes in this terminal."
    if ($Action -eq 'login') {
        & (Get-Command python3 -CommandType Application -ErrorAction Stop | Select-Object -First 1).Source (Join-Path $PSScriptRoot 'accounts.py') login $Name
    }
}

Register-ArgumentCompleter -CommandName cc-account -ParameterName Name -ScriptBlock {
    param($commandName, $parameterName, $wordToComplete)
    $ctx = Get-CCAccountContext
    $names = @('default') + @(Get-ChildItem -LiteralPath (Join-Path $ctx.Root 'profiles') -Directory |
        Where-Object { -not $_.Name.StartsWith('.') } | Select-Object -ExpandProperty Name)
    if (Test-Path -LiteralPath (Join-Path $ctx.Root 'router.json') -PathType Leaf) { $names += 'auto' }
    foreach ($name in $names | Where-Object { $_ -like "$wordToComplete*" }) {
        [Management.Automation.CompletionResult]::new($name, $name, 'ParameterValue', $name)
    }
}
