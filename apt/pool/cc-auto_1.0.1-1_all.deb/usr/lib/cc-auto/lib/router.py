#!/usr/bin/env python3
"""Select local Claude OAuth profiles using quota, through one stable config path.

Linux-only. No third-party dependencies. Tokens are never included in logs/state.
OAuth HTTP details and refresh locks match the installed Claude Code 2.1.294/295.
"""
import argparse
import concurrent.futures
import contextlib
import datetime as dt
import fcntl
import email.utils
import json
import math
import os
from pathlib import Path
import random
import re
import shutil
import signal
import ssl
import subprocess
import statistics
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

SERVICE = 'claude-account-router.service'
CLIENT_ID = '9d1c250a-e61b-44d9-88ed-5944d1962f5e'
USAGE_URL = 'https://api.anthropic.com/api/oauth/usage'
TOKEN_URL = 'https://platform.claude.com/v1/oauth/token'
STOP = threading.Event()


class Busy(Exception):
    pass


class RequestError(Exception):
    def __init__(self, status=None, retry_after=None, redirect=None):
        self.status = status
        self.retry_after = retry_after
        self.redirect = redirect
        super().__init__('network_error' if status is None else f'http_{status}')


def load(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except FileNotFoundError:
        return default


def save(path, data):
    """Publish JSON atomically, with private permissions and no token output."""
    path = Path(path)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w') as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(data, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(temporary)


def root_path():
    return Path(os.environ.get('CLAUDE_ACCOUNTS_ROOT', Path.home() / '.claude-accounts')).absolute()


@contextlib.contextmanager
def router_lock(root):
    with (root / 'router.lock').open('a') as stream:
        os.chmod(stream.name, 0o600)
        fcntl.flock(stream, fcntl.LOCK_EX)
        yield


@contextlib.contextmanager
def oauth_locks(directories):
    """Coordinate with Claude's current and legacy refresh locks.

    Never remove someone else's lock or write through a moving config alias.
    Heartbeats prevent Claude from treating a slow HTTP refresh as a dead holder.
    """
    held = []
    stopped = threading.Event()
    heartbeat = None
    try:
        for directory in sorted({Path(p).resolve() for p in directories}, key=str):
            for lock in (directory / '.oauth_refresh.lock', Path(str(directory) + '.lock')):
                try:
                    lock.mkdir(mode=0o700)
                except FileExistsError:
                    raise Busy('oauth_refresh_in_progress') from None
                held.append((lock, lock.stat().st_ino))

        def beat():
            while not stopped.wait(5):
                for lock, inode in held:
                    with contextlib.suppress(FileNotFoundError):
                        if lock.stat().st_ino == inode:
                            os.utime(lock, None)

        heartbeat = threading.Thread(target=beat, daemon=True)
        heartbeat.start()
        yield
    finally:
        stopped.set()
        if heartbeat:
            heartbeat.join(timeout=1)
        for lock, inode in reversed(held):
            with contextlib.suppress(FileNotFoundError):
                if lock.stat().st_ino == inode:
                    lock.rmdir()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


def request_json(url, bearer=None, body=None):
    # Fixed HTTPS hosts only. Redirects are refused so credentials never follow one.
    if url not in (USAGE_URL, TOKEN_URL):
        raise ValueError('Unexpected OAuth endpoint')
    headers = {'Content-Type': 'application/json', 'User-Agent': 'claude-account-router/1.0'}
    if bearer:
        headers.update(Authorization='Bearer ' + bearer, **{'anthropic-beta': 'oauth-2025-04-20'})
    request = urllib.request.Request(url, headers=headers, data=None if body is None else json.dumps(body).encode())
    opener = urllib.request.build_opener(NoRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(request, timeout=20) as response:
            raw = response.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                raise RequestError()
            return json.loads(raw)
    except urllib.error.HTTPError as error:
        retry = error.headers.get('Retry-After')
        try:
            retry = float(retry)
        except (TypeError, ValueError):
            try:
                retry = max(0, email.utils.parsedate_to_datetime(retry).timestamp() - time.time())
            except (TypeError, ValueError):
                retry = None
        location = error.headers.get('Location', '') if 300 <= error.code < 400 else ''
        parsed = urllib.parse.urlsplit(location)
        redirect = ({'host': parsed.hostname, 'path': parsed.path or '/'}
                    if parsed.hostname else None)
        raise RequestError(error.code, retry, redirect) from None
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError):
        raise RequestError() from None


def credentials(directory):
    data = load(directory / '.credentials.json', {})
    oauth = data.get('claudeAiOauth', {})
    if not oauth.get('accessToken'):
        raise ValueError('not_logged_in')
    return data, oauth


def credentials_mtime_ns(directory):
    try:
        return (directory / '.credentials.json').stat().st_mtime_ns
    except OSError:
        return None


def credentials_changed(directory, observation):
    current = credentials_mtime_ns(directory)
    if current is None:
        return False
    previous = observation.get('credentialsMtimeNs')
    if previous is not None:
        return current != previous
    error_at = observation.get('errorAt')
    return error_at is not None and current / 1_000_000_000 > error_at


def refresh(directory, force=False):
    directory = directory.resolve()
    _, current = credentials(directory)
    if not force and float(current.get('expiresAt') or 0) / 1000 > time.time() + 300:
        return current['accessToken']
    with oauth_locks([directory]):
        data, current = credentials(directory)
        if not force and float(current.get('expiresAt') or 0) / 1000 > time.time() + 300:
            return current['accessToken']
        old_refresh = current.get('refreshToken')
        if not old_refresh:
            raise ValueError('login_required')
        response = request_json(TOKEN_URL, body={
            'grant_type': 'refresh_token', 'refresh_token': old_refresh,
            'client_id': current.get('clientId') or CLIENT_ID,
            'scope': ' '.join(current.get('scopes') or ['user:profile', 'user:inference']),
        })
        if not isinstance(response.get('access_token'), str) or not isinstance(response.get('expires_in'), (int, float)):
            raise ValueError('invalid_refresh_response')
        # A concurrent manual login must never be overwritten by this response.
        latest, latest_oauth = credentials(directory)
        if latest_oauth.get('refreshToken') != old_refresh or latest_oauth.get('accessToken') != current['accessToken']:
            return latest_oauth['accessToken']
        updated = dict(latest_oauth)
        updated.update(accessToken=response['access_token'],
                       refreshToken=response.get('refresh_token') or old_refresh,
                       expiresAt=int((time.time() + response['expires_in']) * 1000))
        if response.get('scope'):
            updated['scopes'] = response['scope'].split()
        if isinstance(response.get('refresh_token_expires_in'), (int, float)):
            updated['refreshTokenExpiresAt'] = int((time.time() + response['refresh_token_expires_in']) * 1000)
        latest['claudeAiOauth'] = updated
        save(directory / '.credentials.json', latest)
        return updated['accessToken']


def normalize_usage(data, model):
    """The live OAuth endpoint reports utilization/percent in 0..100 units."""
    meters = {}
    for key in ('five_hour', 'seven_day', 'seven_day_' + model):
        value = data.get(key)
        if isinstance(value, dict) and isinstance(value.get('utilization'), (int, float)):
            percent = float(value['utilization'])
            if math.isfinite(percent) and percent >= 0:
                meters[key] = {'percent': percent, 'resets_at': value.get('resets_at'),
                               'locked': bool(value.get('locked_reason'))}
    for item in data.get('limits') or []:
        if not isinstance(item, dict):
            continue
        kind = item.get('kind')
        if kind in ('session', 'weekly_all'):
            key = 'five_hour' if kind == 'session' else 'seven_day'
        elif kind == 'weekly_scoped':
            scope = (item.get('scope') or {}).get('model') or {}
            label = str(scope.get('id') or '') + ' ' + str(scope.get('display_name') or '')
            if model not in label.lower():
                continue
            key = 'seven_day_' + model
        else:
            continue
        percent = item.get('percent')
        if isinstance(percent, (int, float)) and math.isfinite(percent) and percent >= 0:
            existing = meters.get(key, {})
            meters[key] = {'percent': float(percent), 'resets_at': item.get('resets_at'),
                           'locked': bool(existing.get('locked')) or item.get('severity') == 'blocked'}
    if 'five_hour' not in meters or 'seven_day' not in meters:
        raise ValueError('unrecognized_usage_response')
    return meters


def profiles(root, manager, config):
    found = {'default': Path(manager.get('defaultConfigDirectory') or manager['sharedDirectory']).resolve()}
    for path in sorted((root / 'profiles').iterdir()):
        if path.is_dir() and not path.name.startswith('.'):
            found[path.name] = path.resolve()
    ordered = [name for name in config['priority'] if name in found]
    if config.get('autoDiscoverProfiles', True):
        ordered += [name for name in found if name not in ordered]
    return {name: found[name] for name in ordered}


def read_config(root):
    config = load(root / 'router.json')
    config.setdefault('candidateIntervalSeconds', 180)
    config.setdefault('candidateStaggerSeconds', 15)
    config.setdefault('429FallbackMaxAgeSeconds', 900)
    config.setdefault('activeIntervalNearSeconds', 60)
    config.setdefault('activeIntervalMediumSeconds', 120)
    config.setdefault('activeIntervalNormalSeconds', 300)
    config.setdefault('recoveryIntervalSeconds', 180)
    config.setdefault('forecastLeadSeconds', 900)
    config.setdefault('forecastMaxThresholdReduction', 15)
    config.setdefault('forecastCyclePressureWeight', 0.25)
    config.setdefault('forecastMinimumSamples', 3)
    config.setdefault('forecastMinimumChangePercent', 0.5)
    config.setdefault('switchCooldownSeconds', 180)
    config.setdefault('accountThresholds', {})
    if not config or not isinstance(config.get('priority'), list) or not config['priority']:
        raise ValueError('router priority must be a nonempty list')
    if len(config['priority']) != len(set(config['priority'])):
        raise ValueError('duplicate account in priority')
    if not 0 < config['switchAtPercent'] <= 100 or not 0 < config['returnBelowPercent'] <= config['switchAtPercent']:
        raise ValueError('invalid usage thresholds')
    if not isinstance(config['accountThresholds'], dict):
        raise ValueError('accountThresholds must be an object')
    for name, thresholds in config['accountThresholds'].items():
        if not isinstance(name, str) or not isinstance(thresholds, dict) or set(thresholds) - {'switchAtPercent', 'returnBelowPercent', 'meterThresholds', 'pacedMeterThresholds'}:
            raise ValueError('invalid account threshold override')
        switch = thresholds.get('switchAtPercent', config['switchAtPercent'])
        recovery = thresholds.get('returnBelowPercent', config['returnBelowPercent'])
        if not 0 < switch <= 100 or not 0 < recovery <= switch:
            raise ValueError('invalid account threshold override')
        meter_thresholds = thresholds.get('meterThresholds', {})
        if (not isinstance(meter_thresholds, dict) or not meter_thresholds
                or any(not isinstance(key, str) or not isinstance(value, (int, float))
                       or isinstance(value, bool) or not 0 < value <= 100
                       for key, value in meter_thresholds.items())):
            if 'meterThresholds' in thresholds:
                raise ValueError('invalid meter threshold override')
        paced = thresholds.get('pacedMeterThresholds', {})
        if (not isinstance(paced, dict) or not paced
                or any(not isinstance(key, str) or not valid_paced_limit(value)
                       for key, value in paced.items())):
            if 'pacedMeterThresholds' in thresholds:
                raise ValueError('invalid paced meter threshold override')
    if config['intervalSeconds'] < 60:
        raise ValueError('usage checks must be at least 60 seconds apart')
    if not isinstance(config['429FallbackMaxAgeSeconds'], (int, float)) or not 60 <= config['429FallbackMaxAgeSeconds'] <= 3600:
        raise ValueError('429FallbackMaxAgeSeconds must be between 60 and 3600')
    for key in ('candidateIntervalSeconds', 'activeIntervalNearSeconds',
                'activeIntervalMediumSeconds', 'activeIntervalNormalSeconds', 'recoveryIntervalSeconds'):
        if not isinstance(config[key], (int, float)) or isinstance(config[key], bool) or config[key] < 60:
            raise ValueError(f'{key} must be at least 60 seconds')
    if not (config['activeIntervalNearSeconds'] <= config['activeIntervalMediumSeconds']
            <= config['activeIntervalNormalSeconds']):
        raise ValueError('active polling intervals must increase with quota headroom')
    if not isinstance(config['forecastLeadSeconds'], (int, float)) or not 60 <= config['forecastLeadSeconds'] <= 3600:
        raise ValueError('forecastLeadSeconds must be 60..3600')
    if not isinstance(config['forecastMaxThresholdReduction'], (int, float)) or not 0 <= config['forecastMaxThresholdReduction'] <= 30:
        raise ValueError('forecastMaxThresholdReduction must be 0..30 percentage points')
    if not isinstance(config['forecastCyclePressureWeight'], (int, float)) or not 0 <= config['forecastCyclePressureWeight'] <= 1:
        raise ValueError('forecastCyclePressureWeight must be 0..1')
    if not isinstance(config['forecastMinimumSamples'], int) or isinstance(config['forecastMinimumSamples'], bool) or not 3 <= config['forecastMinimumSamples'] <= 10:
        raise ValueError('forecastMinimumSamples must be 3..10')
    if not isinstance(config['forecastMinimumChangePercent'], (int, float)) or not 0.1 <= config['forecastMinimumChangePercent'] <= 10:
        raise ValueError('forecastMinimumChangePercent must be 0.1..10')
    if not isinstance(config['switchCooldownSeconds'], (int, float)) or not 0 <= config['switchCooldownSeconds'] <= 1800:
        raise ValueError('switchCooldownSeconds must be 0..1800')
    return config


def poll(directory, old, config, now):
    # Honor server backoff even when a user manually runs `check` repeatedly.
    if STOP.is_set():
        return old
    if now < old.get('nextCheckAt', 0):
        changed = credentials_changed(directory, old)
        if old.get('error') != 'not_logged_in' and not changed:
            return old
        if old.get('error') == 'not_logged_in':
            # A new profile is discovered before the browser login finishes.
            # Once credentials appear, its earlier local error must not delay
            # the first usage request.
            try:
                credentials(directory)
            except (ValueError, OSError, AttributeError):
                return old
        old = dict(old, failures=0)
    try:
        token = refresh(directory)
        try:
            data = request_json(USAGE_URL, bearer=token)
        except RequestError as error:
            if error.status != 401:
                raise
            token = refresh(directory, force=True)
            data = request_json(USAGE_URL, bearer=token)
        meters = normalize_usage(data, config.get('model', 'opus'))
        return {'ok': True, 'meters': meters, 'checkedAt': time.time(),
                'nextCheckAt': time.time() + config['intervalSeconds'], 'failures': 0,
                'credentialsMtimeNs': credentials_mtime_ns(directory)}
    except (RequestError, ValueError, Busy, OSError, KeyError, TypeError) as error:
        failures = min(old.get('failures', 0) + 1, 6)
        if isinstance(error, RequestError) and error.status == 429:
            # A 429 should cool down more aggressively than a normal network
            # failure. Grow the per-profile delay and add positive jitter so
            # accounts throttled together do not retry as a synchronized burst.
            base = min(1800, max(300, config['intervalSeconds']) * 2 ** (failures - 1))
            delay = max(base, min(86400, max(300, error.retry_after or 0)))
            delay += random.uniform(0, min(45, delay * 0.1))
        else:
            delay = max(config['intervalSeconds'], min(1800, 60 * 2 ** (failures - 1)))
        # Retain the last observation for display, but never select on a failed read.
        expected = {'not_logged_in', 'login_required', 'invalid_refresh_response', 'unrecognized_usage_response'}
        redirect = error.redirect if isinstance(error, RequestError) else None
        login_redirect = bool(redirect and re.search(
            r'/(?:login|log-in|signin|sign-in)(?:/|$)', redirect['path'], re.I)
            and redirect['host'] in {'claude.ai', 'www.claude.ai', 'console.anthropic.com', 'auth.anthropic.com'})
        reason = ('login_required' if login_redirect else
                  str(error) if isinstance(error, (RequestError, Busy)) or str(error) in expected
                  else type(error).__name__)
        return dict(old, ok=False, error=reason,
                    errorAt=now, nextCheckAt=now + delay, failures=failures,
                    credentialsMtimeNs=credentials_mtime_ns(directory),
                    errorInfo=({'redirectHost': redirect['host'], 'redirectPath': redirect['path']}
                               if redirect else None))


def usable(observation, threshold, now, max_age):
    # A cached snapshot remains visible after a failed poll, but it cannot
    # authorize account selection: consumption may have continued since it.
    return (observation.get('ok')
            and now - observation.get('checkedAt', 0) <= max_age
            and bool(observation.get('meters'))
            and all(not meter.get('locked') and meter['percent'] < meter_limit(threshold, key, meter, now)
                    for key, meter in observation['meters'].items()))


def scale_threshold(threshold, factor):
    if isinstance(threshold, dict):
        scaled = {}
        for key, value in threshold.items():
            if isinstance(value, dict):
                item = dict(value)
                item['maxPercent'] *= factor
                item['minPercent'] = item.get('minPercent', 0) * factor
                scaled[key] = item
            elif isinstance(value, (int, float)):
                scaled[key] = value * factor
            else:
                scaled[key] = value
        return scaled
    return threshold * factor


def fallback_factor(observation, now, max_age):
    checked = observation.get('checkedAt')
    if observation.get('error') != 'http_429' or not checked or not observation.get('meters'):
        return None
    age = max(0, now - checked)
    if age >= max_age:
        return None
    # As quota data ages, shrink the usable threshold linearly to zero.
    return max(0.0, 1.0 - age / max_age)


def fallback_usable(observation, threshold, now, max_age):
    factor = fallback_factor(observation, now, max_age)
    if factor is None:
        return False
    conservative = scale_threshold(threshold, factor)
    return all(not meter.get('locked')
               and meter['percent'] < meter_limit(conservative, key, meter, now)
               for key, meter in observation['meters'].items())


def fallback_headroom(observation, threshold, now, max_age):
    factor = fallback_factor(observation, now, max_age)
    if factor is None:
        return None
    conservative = scale_threshold(threshold, factor)
    margins = [meter_limit(conservative, key, meter, now) - meter['percent']
               for key, meter in observation['meters'].items()]
    if not margins or any(margin <= 0 or meter.get('locked')
                          for margin, meter in zip(margins, observation['meters'].values())):
        return None
    return min(margins)


def meter_limit(threshold, key, meter, now):
    limit = threshold.get(key, threshold.get('_default', 100)) if isinstance(threshold, dict) else threshold
    if isinstance(limit, dict):
        maximum = limit['maxPercent']
        reset = meter.get('resets_at')
        try:
            parsed_reset = dt.datetime.fromisoformat(reset.replace('Z', '+00:00'))
            if parsed_reset.tzinfo is None:
                parsed_reset = parsed_reset.replace(tzinfo=dt.timezone.utc)
            reset_at = parsed_reset.timestamp()
            cycle_seconds = limit['cycleSeconds']
            elapsed = min(1.0, max(0.0, (now - (reset_at - cycle_seconds)) / cycle_seconds))
            minimum = limit.get('minPercent', 0)
            return minimum + (maximum - minimum) * elapsed
        except (AttributeError, TypeError, ValueError, OverflowError):
            # Missing reset metadata falls back to the hard maximum.
            return maximum
    return limit


def valid_paced_limit(value):
    # A scalar remains supported as the legacy maxPercent shorthand.
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return 0 < value <= 100
    if not isinstance(value, dict) or set(value) - {'minPercent', 'maxPercent', 'cycleSeconds'}:
        return False
    minimum = value.get('minPercent', 0)
    maximum = value.get('maxPercent')
    cycle = value.get('cycleSeconds', 604800)
    return (isinstance(minimum, (int, float)) and not isinstance(minimum, bool)
            and isinstance(maximum, (int, float)) and not isinstance(maximum, bool)
            and 0 <= minimum <= maximum <= 100
            and isinstance(cycle, (int, float)) and not isinstance(cycle, bool)
            and cycle > 0)


def threshold_for(name, role, config):
    key = 'switchAtPercent' if role == 'switch' else 'returnBelowPercent'
    override = config.get('accountThresholds', {}).get(name, {})
    if 'meterThresholds' in override or 'pacedMeterThresholds' in override:
        limits = dict(override.get('meterThresholds', {}))
        limits.update({meter: (dict(maxPercent=value, cycleSeconds=604800)
                               if isinstance(value, (int, float)) else
                               dict(value, cycleSeconds=value.get('cycleSeconds', 604800)))
                       for meter, value in override.get('pacedMeterThresholds', {}).items()})
        limits['_default'] = override.get(key, config[key])
        return limits
    return override.get(key, config[key])


def remember_usage_history(previous, current, now):
    """Keep bounded, reset-aware utilization samples for forecasting."""
    history = {key: list(value) for key, value in previous.get('usageHistory', {}).items()}
    if current.get('ok') and current.get('checkedAt'):
        checked = current['checkedAt']
        for name, meter in current.get('meters', {}).items():
            reset = meter.get('resets_at')
            points = history.get(name, [])
            if points and points[-1].get('reset') != reset:
                points = []
            if not points or points[-1].get('at') != checked:
                points.append({'at': checked, 'percent': float(meter['percent']), 'reset': reset})
            cutoff = now - 86400
            history[name] = [point for point in points if point.get('at', 0) >= cutoff][-64:]
    current['usageHistory'] = history
    return current


def forecast_rate(observation, meter_name, now, config):
    meter = observation.get('meters', {}).get(meter_name, {})
    window = 3600 if meter_name == 'five_hour' else 6 * 3600
    reset = meter.get('resets_at')
    points = [point for point in observation.get('usageHistory', {}).get(meter_name, [])
              if point.get('reset') == reset and now - point.get('at', 0) <= window]
    points.sort(key=lambda point: point['at'])
    minimum = config.get('forecastMinimumSamples', 3)
    max_sample_age = max(900, config.get('candidateIntervalSeconds', 900) * 2)
    if len(points) < minimum:
        return {'ready': False, 'reason': 'warming', 'samples': len(points),
                'rate': 0.0, 'confidence': 0.0}
    if not points or now - points[-1]['at'] > max_sample_age:
        return {'ready': False, 'reason': 'stale', 'samples': len(points),
                'rate': 0.0, 'confidence': 0.0}
    delta = max(point['percent'] for point in points) - min(point['percent'] for point in points)
    if delta < config.get('forecastMinimumChangePercent', 0.5):
        return {'ready': True, 'samples': len(points), 'rate': 0.0, 'confidence': 0.0}
    slopes = []
    for index, left in enumerate(points[:-1]):
        for right in points[index + 1:]:
            hours = (right['at'] - left['at']) / 3600
            if hours >= 1 / 120:
                slopes.append((right['percent'] - left['percent']) / hours)
    rate = max(0.0, statistics.median(slopes)) if slopes else 0.0
    sample_confidence = min(1.0, (len(points) - minimum + 1) / 3)
    change_confidence = min(1.0, delta / max(1.0, config.get('forecastMinimumChangePercent', 0.5) * 2))
    confidence = sample_confidence * change_confidence if rate > 0 else 0.0
    return {'ready': True, 'samples': len(points), 'rate': rate, 'confidence': confidence,
            'delta': delta}


def dynamic_threshold_for(name, role, observation, config, now):
    """Lower (never raise) effective thresholds when a confirmed burn rate risks a near-term hit."""
    base = threshold_for(name, role, config)
    base_default = base.get('_default', 100) if isinstance(base, dict) else base
    effective = {'_default': base_default}
    forecasts = {}
    lead_seconds = config.get('forecastLeadSeconds', 900)
    max_reduction = config.get('forecastMaxThresholdReduction', 15)
    for meter_name, meter in observation.get('meters', {}).items():
        base_limit = meter_limit(base, meter_name, meter, now)
        trend = forecast_rate(observation, meter_name, now, config)
        reduction = 0.0
        reset_remaining = seconds_until_reset(meter, now)
        projected_at_reset = None
        if trend.get('rate', 0) > 0 and trend.get('confidence', 0) > 0:
            horizon = min(lead_seconds, reset_remaining) if reset_remaining is not None else lead_seconds
            projected_burn = trend['rate'] * horizon / 3600
            pressure_limit = max(0.0, 100.0 - projected_burn)
            near_term_reduction = max(0.0, base_limit - pressure_limit)
            if reset_remaining is not None:
                projected_at_reset = float(meter.get('percent', 0)) + trend['rate'] * reset_remaining / 3600
                cycle_overrun = max(0.0, projected_at_reset - 100.0)
                cycle_reduction = cycle_overrun * config.get('forecastCyclePressureWeight', 0.25)
            else:
                cycle_reduction = 0.0
            reduction = min(max_reduction, max(near_term_reduction, cycle_reduction))
            reduction *= trend['confidence']
        current_limit = max(0.0, base_limit - reduction)
        effective[meter_name] = current_limit
        rate = trend.get('rate', 0)
        current = float(meter.get('percent', 0))
        eta_full = max(0.0, 100.0 - current) / rate * 3600 if rate > 0 else None
        eta_limit = max(0.0, current_limit - current) / rate * 3600 if rate > 0 else None
        if reset_remaining is not None:
            if eta_full is not None and eta_full > reset_remaining:
                eta_full = None
            if eta_limit is not None and eta_limit > reset_remaining:
                eta_limit = None
        forecasts[meter_name] = {**trend, 'baseLimit': base_limit, 'limit': current_limit,
                                 'reduction': reduction, 'etaFull': eta_full,
                                 'etaLimit': eta_limit, 'resetRemaining': reset_remaining,
                                 'projectedAtReset': projected_at_reset}
    return effective, forecasts


def active_poll_interval(name, observation, config, now):
    if not observation.get('ok') or not observation.get('meters'):
        return config['activeIntervalNormalSeconds']
    threshold, _ = dynamic_threshold_for(name, 'switch', observation, config, now)
    short_window_margins = [meter_limit(threshold, key, meter, now) - meter['percent']
                            for key, meter in observation['meters'].items()
                            if not meter.get('locked') and ('hour' in key or 'session' in key)]
    margins = short_window_margins or [meter_limit(threshold, key, meter, now) - meter['percent']
                                       for key, meter in observation['meters'].items()
                                       if not meter.get('locked')]
    if not margins:
        return config['activeIntervalNearSeconds']
    headroom = min(margins)
    if headroom <= 10:
        return config['activeIntervalNearSeconds']
    if headroom <= 25:
        return config['activeIntervalMediumSeconds']
    return config['activeIntervalNormalSeconds']


def choose(accounts, observations, active, config, now):
    max_age = config.get('maxObservationAgeSeconds', 180)
    fallback_age = config.get('429FallbackMaxAgeSeconds', 900)
    # Prefer any account with a successful current reading over every fallback.
    for name in accounts:
        role = 'switch' if name == active else 'return'
        observation = observations.get(name, {})
        threshold, _ = dynamic_threshold_for(name, role, observation, config, now)
        if usable(observation, threshold, now, max_age):
            return name
    # If every profile is rate-limited, keep service available only while a
    # cached snapshot has conservative headroom. The headroom decays to zero.
    fallbacks = []
    for rank, name in enumerate(accounts):
        role = 'switch' if name == active else 'return'
        observation = observations.get(name, {})
        threshold, _ = dynamic_threshold_for(name, role, observation, config, now)
        margin = fallback_headroom(observation, threshold, now, fallback_age)
        if margin is not None:
            fallbacks.append((margin, -rank, name))
    if fallbacks:
        return max(fallbacks)[2]
    # Never retain an account whose current eligibility cannot be verified.
    return None


def pointer_account(pointer, accounts):
    if not pointer.is_symlink():
        return None
    target = pointer.resolve()
    return next((name for name, directory in accounts.items() if directory == target), None)


def switch_pointer(pointer, target, manager):
    if pointer.exists() and not pointer.is_symlink():
        raise ValueError('fixedConfigDirectory exists and is not a symlink; refusing overwrite')
    previous = pointer.resolve() if pointer.is_symlink() else None
    touched = [target]
    if previous and previous.is_dir() and previous != target:
        touched.append(previous)
    temporary = pointer.with_name('.' + pointer.name + '-' + str(os.getpid()))
    with oauth_locks(touched):
        try:
            temporary.symlink_to(target, target_is_directory=True)
            os.replace(temporary, pointer)
            # Token reload uses stat() per turn. Wake global-config watchers too,
            # including a watcher attached to the previous directory before swap.
            for directory in touched:
                for filename in ('.credentials.json', '.claude.json'):
                    path = directory / filename
                    if path.is_file():
                        os.utime(path, None)
        finally:
            with contextlib.suppress(FileNotFoundError):
                temporary.unlink()


def hold_profile(root):
    """Return an empty private config directory used to fail closed on quota."""
    path = root / 'profiles' / '.cc-auto-hold'
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path, 0o700)
    return path


def tick(root):
    with router_lock(root):
        config = read_config(root)
        manager = load(root / 'manager.json')
        accounts = profiles(root, manager, config)
        state = load(root / 'router-state.json', {})
        observations = state.get('accounts', {})
        pointer = Path(config['fixedConfigDirectory'])
        active = pointer_account(pointer, accounts)
        polling_active = (active if active in accounts else
                          min(accounts, key=lambda name: observations.get(name, {}).get('nextCheckAt', 0))
                          if accounts else None)
        candidate_rank = 0
        account_configs = {}
        now = time.time()
        for name in accounts:
            account_config = dict(config)
            old = observations.get(name, {})
            if name == polling_active:
                if active not in accounts and state.get('paused'):
                    old = dict(old, nextCheckAt=min(old.get('nextCheckAt', now), now))
                account_config['intervalSeconds'] = (
                    active_poll_interval(name, old, config, now) if name == active
                    else config['recoveryIntervalSeconds'])
            else:
                candidate_rank += 1
                account_config['intervalSeconds'] = config['candidateIntervalSeconds']
                # On migration/new profile discovery, offset standby checks so
                # they do not all hit the usage endpoint in the same tick.
                stagger = candidate_rank * config['candidateStaggerSeconds']
                if old.get('ok') and state.get('pollingPolicyVersion', 1) < 2:
                    old = dict(old, nextCheckAt=max(old.get('nextCheckAt', 0), now + stagger))
                elif not old.get('checkedAt') and not old.get('nextCheckAt'):
                    old = dict(old, nextCheckAt=now + stagger)
                observations[name] = old
            account_configs[name] = account_config
        # Only due profiles are queried by poll(). Standby profiles use a slower,
        # staggered cadence; the active account keeps the configured fast cadence.
        # Bound concurrency so refresh locks and timeouts cannot block the router.
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, max(1, len(accounts)))) as pool:
            pending = {name: pool.submit(poll, directory, observations.get(name, {}), account_configs[name], now)
                       for name, directory in accounts.items()}
            for name, future in pending.items():
                previous = observations.get(name, {})
                observations[name] = remember_usage_history(previous, future.result(), now)
        if STOP.is_set():
            return state
        now = time.time()
        chosen = choose(accounts, observations, active, config, now)
        switch_error = None
        last_switch_at = state.get('lastSwitchAt', 0) or 0
        last_switch_reason = state.get('lastSwitchReason')
        if state.get('active') != active and active in accounts:
            last_switch_at = now
        if chosen and chosen != active and active in accounts:
            current = observations.get(active, {})
            active_threshold, active_forecasts = dynamic_threshold_for(
                active, 'switch', current, config, now)
            active_safe = (usable(current, active_threshold, now,
                                  config.get('maxObservationAgeSeconds', 180))
                           or fallback_usable(current, active_threshold, now,
                                               config.get('429FallbackMaxAgeSeconds', 900)))
            safety = max(config.get('forecastLeadSeconds', 900),
                         config.get('activeIntervalNormalSeconds', 300) * 2)
            urgent = any(item.get('etaLimit') is not None and item['etaLimit'] <= safety
                         for item in active_forecasts.values())
            cooldown_left = config.get('switchCooldownSeconds', 180) - (now - last_switch_at)
            if cooldown_left > 0 and active_safe and not urgent:
                chosen = active
                switch_error = 'switch cooldown ' + age_text(cooldown_left)
        paused = False
        if chosen and chosen != active:
            try:
                switch_pointer(pointer, accounts[chosen], manager)
                print(f'{dt.datetime.now(dt.timezone.utc).isoformat()} selected {chosen} (was {active or "unset"})', flush=True)
                last_switch_at = now
                last_switch_reason = 'forecast' if (active in accounts and any(
                    item.get('etaLimit') is not None and
                    item['etaLimit'] <= max(config.get('forecastLeadSeconds', 900),
                                             config.get('activeIntervalNormalSeconds', 300) * 2)
                    for item in dynamic_threshold_for(
                        active, 'switch', observations.get(active, {}), config, now)[1].values())) else 'selection'
                active = chosen
                chosen_observation = observations.get(chosen, {})
                if chosen_observation.get('ok'):
                    chosen_observation['nextCheckAt'] = min(
                        chosen_observation.get('nextCheckAt', now + config['intervalSeconds']),
                        now + config['intervalSeconds'])
            except (Busy, ValueError, OSError) as error:
                switch_error = str(error) if isinstance(error, Busy) else type(error).__name__
        elif chosen is None and active in accounts:
            try:
                switch_pointer(pointer, hold_profile(root), manager)
                print(f'{dt.datetime.now(dt.timezone.utc).isoformat()} paused routing (was {active}; no verified eligible quota)', flush=True)
                active = None
                paused = True
            except (Busy, ValueError, OSError) as error:
                switch_error = str(error) if isinstance(error, Busy) else type(error).__name__
        if not paused and active is None:
            hold = root / 'profiles' / '.cc-auto-hold'
            paused = pointer.is_symlink() and pointer.resolve() == hold.resolve()
        any_usable = any(usable(observations.get(name, {}),
                                dynamic_threshold_for(name, 'switch' if name == active else 'return',
                                                      observations.get(name, {}), config, now)[0], now,
                               config.get('maxObservationAgeSeconds', 180)) for name in accounts)
        state = {'updatedAt': now, 'active': active, 'fixedConfigDirectory': str(pointer),
                 'pollingPolicyVersion': 2,
                 'priority': list(accounts), 'switchAtPercent': config['switchAtPercent'],
                 'returnBelowPercent': config['returnBelowPercent'],
                 'accountThresholds': config.get('accountThresholds', {}), 'model': config.get('model', 'opus'),
                 'maxObservationAgeSeconds': config.get('maxObservationAgeSeconds', 180),
                 '429FallbackMaxAgeSeconds': config.get('429FallbackMaxAgeSeconds', 900),
                 'selectionMode': ('429_fallback' if active and observations.get(active, {}).get('error') == 'http_429'
                                   else 'fresh' if active else 'paused'),
                 'available': any_usable or any(fallback_usable(
                     observations.get(name, {}),
                     dynamic_threshold_for(name, 'switch' if name == active else 'return',
                                           observations.get(name, {}), config, now)[0], now,
                     config.get('429FallbackMaxAgeSeconds', 900)) for name in accounts),
                 'paused': paused, 'switchError': switch_error,
                 'lastSwitchAt': last_switch_at, 'lastSwitchReason': last_switch_reason,
                 'forecastLeadSeconds': config.get('forecastLeadSeconds', 900),
                 'forecastMaxThresholdReduction': config.get('forecastMaxThresholdReduction', 15),
                 'forecastCyclePressureWeight': config.get('forecastCyclePressureWeight', 0.25),
                 'forecastMinimumSamples': config.get('forecastMinimumSamples', 3),
                 'forecastMinimumChangePercent': config.get('forecastMinimumChangePercent', 0.5),
                 'switchCooldownSeconds': config.get('switchCooldownSeconds', 180),
                 'accounts': {name: observations.get(name, {}) for name in accounts}}
        save(root / 'router-state.json', state)
        return state


def age_text(seconds):
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f'{seconds}s'
    if seconds < 3600:
        return f'{seconds // 60}m'
    return f'{seconds // 3600}h {(seconds % 3600) // 60}m'


def duration_text(seconds):
    seconds = max(0, int(seconds))
    days, remainder = divmod(seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes = remainder // 60
    if days:
        return f'{days}d {hours}h'
    if hours:
        return f'{hours}h {minutes}m'
    if minutes:
        return f'{minutes}m'
    return '<1m'


def reset_description(name, meter, now):
    reset = meter.get('resets_at')
    if not reset:
        return 'reset time unavailable'
    try:
        parsed = dt.datetime.fromisoformat(reset.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.timezone.utc)
        local = parsed.astimezone()
        stamp = local.strftime('%d/%m %H:%M')
        remaining = max(0, parsed.timestamp() - now)
        if name.startswith('seven_day'):
            weekday = ('T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN')[local.weekday()]
            days = math.ceil(remaining / 86400)
            return f'{weekday} {stamp} ({days}d)'
        minutes = math.ceil(remaining / 60)
        return f'{stamp} ({minutes}m)'
    except (AttributeError, TypeError, ValueError, OverflowError):
        return 'invalid'


def seconds_until_reset(meter, now):
    reset = meter.get('resets_at')
    if not reset:
        return None
    try:
        parsed = dt.datetime.fromisoformat(reset.replace('Z', '+00:00'))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.timezone.utc)
        return max(0.0, parsed.timestamp() - now)
    except (AttributeError, TypeError, ValueError, OverflowError):
        return None


def observation_health(entry, now):
    error = entry.get('error')
    checked = entry.get('checkedAt')
    meters = bool(entry.get('meters'))
    age = age_text(now - checked) if checked else None
    retry = entry.get('nextCheckAt', 0) - now
    retry_text = f'; retry in {age_text(retry)}' if retry > 0 else ''
    if entry.get('ok'):
        return f'ok; updated {age} ago' if age else 'ok'
    if error == 'http_429':
        cached = f'cached usage from {age} ago' if meters and age else 'no cached usage'
        return f'rate-limited (HTTP 429); {cached}{retry_text}'
    if error == 'login_required':
        return f'login required; re-login this profile{retry_text}'
    if error:
        cached = f'; cached usage from {age} ago' if meters and age else ''
        return f'{error}{cached}{retry_text}'
    return f'unknown; cached usage from {age} ago' if meters and age else 'unknown'


def table_state(entry, now):
    checked = entry.get('checkedAt')
    if entry.get('ok'):
        return f'ok {age_text(now - checked)}' if checked else 'ok'
    error = entry.get('error') or 'unknown'
    labels = {'http_403': '403', 'http_302': '302', 'http_401': '401',
              'http_429': '429', 'login_required': 'LOGIN'}
    state = labels.get(error, error)
    if error == 'login_required':
        return 'LOGIN needed'
    if checked:
        state += f'; old {duration_text(now - checked)}'
    retry = entry.get('nextCheckAt', 0) - now
    if retry > 0:
        state += f'; retry {age_text(retry)}'
    return state


def rolling_local_tokens(root, profile, now, model=None):
    totals = {'five_hour': 0, 'seven_day': 0}
    ledger = root / 'usage' / 'events.jsonl'
    if not ledger.is_file():
        return totals
    try:
        with ledger.open(encoding='utf-8') as stream:
            for line in stream:
                try:
                    row = json.loads(line)
                    if row.get('profile') != profile:
                        continue
                    if model and model not in str(row.get('model') or '').lower():
                        continue
                    stamp = row.get('timestamp')
                    if not isinstance(stamp, (int, float)):
                        continue
                    age = now - stamp
                    if age < 0 or age > 7 * 86400:
                        continue
                    tokens = sum(int(row.get(key, 0) or 0) for key in (
                        'input_tokens', 'cache_creation_input_tokens',
                        'cache_read_input_tokens', 'output_tokens'))
                    totals['seven_day'] += tokens
                    if age <= 5 * 3600:
                        totals['five_hour'] += tokens
                except (ValueError, TypeError):
                    continue
    except OSError:
        pass
    return totals


def compact_tokens(count):
    if count >= 1_000_000:
        return f'{count / 1_000_000:.1f}M'
    if count >= 1_000:
        return f'{count / 1_000:.1f}k'
    return str(count)


def usage_bar(value, color):
    width = 12
    percent = max(0.0, min(100.0, float(value.get('percent', 0))))
    used_cells = round(percent * width / 100)
    empty_cells = width - used_cells
    if color:
        bar = '\x1b[90m' + '█' * used_cells + '\x1b[2m' + '░' * empty_cells + '\x1b[0m'
    else:
        bar = 'G' * used_cells + '-' * empty_cells
    return f'[{bar}] {percent:g}%'


def visible_len(value):
    return len(re.sub(r'\x1b\[[0-9;]*m', '', value))


def display(state, now=None):
    if not state:
        print('No usage observation yet. Run cc-auto check.')
        return
    now = time.time() if now is None else now
    color = sys.stdout.isatty()
    print('Active:', state.get('active') or '(not selected)')
    if state.get('selectionMode') == '429_fallback':
        print('MODE: rate-limited fallback; quota headroom shrinks with cache age')
    print('VS Code config:', state.get('fixedConfigDirectory'))
    print('Priority:', ' > '.join(state.get('priority', [])))
    print('ADAPTIVE',
          f"{duration_text(state.get('forecastLeadSeconds', 900))} forecast lead; "
          f"max -{state.get('forecastMaxThresholdReduction', 15):g}pp; "
          f"cycle pressure ×{state.get('forecastCyclePressureWeight', 0.25):g}; "
          f"{state.get('forecastMinimumSamples', 3)} samples minimum; "
          f"{duration_text(state.get('switchCooldownSeconds', 180))} switch cooldown")
    policy_rows = [[
        'global',
        f"switch at {state.get('switchAtPercent')}%; return below {state.get('returnBelowPercent')}%"
    ]]
    for name, thresholds in state.get('accountThresholds', {}).items():
        rules = []
        if 'meterThresholds' in thresholds:
            rules.extend(f'{meter} < {percent}%' for meter, percent in thresholds['meterThresholds'].items())
        if 'pacedMeterThresholds' in thresholds:
            for meter, value in thresholds['pacedMeterThresholds'].items():
                if isinstance(value, (int, float)):
                    minimum, maximum, cycle = 0, value, 604800
                else:
                    minimum = value.get('minPercent', 0)
                    maximum = value['maxPercent']
                    cycle = value.get('cycleSeconds', 604800)
                rules.append(f'{meter} paced {minimum:g}–{maximum:g}% / {cycle / 86400:g}d')
        if rules:
            policy_rows.append([name, '; '.join(rules) + ' (switch + return)'])
        else:
            switch = thresholds.get('switchAtPercent', state.get('switchAtPercent'))
            recovery = thresholds.get('returnBelowPercent', state.get('returnBelowPercent'))
            policy_rows.append([name, f'switch/return at {switch}% / {recovery}%'])
    policy_width = max(len(row[0]) for row in policy_rows)
    print('POLICY')
    for scope, rule in policy_rows:
        print(f'  {scope.ljust(policy_width)}  {rule}')
    names = state.get('priority', [])
    meter_names = []
    for name in names:
        for meter in state.get('accounts', {}).get(name, {}).get('meters', {}):
            if meter not in meter_names:
                meter_names.append(meter)
    local_counts = {name: rolling_local_tokens(root_path(), name, now) for name in names}
    local_by_meter = {}
    for meter in meter_names:
        window = 'five_hour' if meter == 'five_hour' else 'seven_day'
        if meter.startswith('seven_day_'):
            model = meter.removeprefix('seven_day_').lower()
            local_by_meter[meter] = {
                name: rolling_local_tokens(root_path(), name, now, model)[window] for name in names}
        else:
            local_by_meter[meter] = {name: local_counts[name][window] for name in names}
    headers = ['ACCOUNT', 'STATE']
    for meter in meter_names:
        headers.extend([f'{meter} USE', 'LOCAL TOKENS', 'LIMIT', 'RESET'])
    rows = []
    row_forecasts = {}
    for name in names:
        entry = state.get('accounts', {}).get(name, {})
        row = [name, table_state(entry, now)]
        role = 'switch' if name == state.get('active') else 'return'
        base_threshold = threshold_for(name, role, state)
        threshold, forecasts = dynamic_threshold_for(name, role, entry, state, now)
        row_forecasts[name] = forecasts
        meters = entry.get('meters', {})
        factor = fallback_factor(entry, now, state.get('429FallbackMaxAgeSeconds', 900))
        if factor is not None:
            threshold = scale_threshold(threshold, factor)
            base_threshold = scale_threshold(base_threshold, factor)
        for meter in meter_names:
            value = meters.get(meter)
            if not value:
                row.extend(['—', '—', '—', '—'])
                continue
            effective = meter_limit(threshold, meter, value, now)
            base_effective = meter_limit(base_threshold, meter, value, now)
            raw_limit = (base_threshold.get(meter, base_threshold.get('_default', 100))
                         if isinstance(base_threshold, dict) else base_threshold)
            trend = forecasts.get(meter, {})
            if trend.get('reduction', 0) >= 0.1:
                limit_text = f'<{effective:.1f}% auto (base {base_effective:g}%)'
            elif factor is not None:
                if isinstance(raw_limit, dict):
                    minimum = raw_limit.get('minPercent', 0)
                    limit_text = f'{effective:.1f}% ({minimum:.1f}–{raw_limit["maxPercent"]:.1f}%)'
                else:
                    limit_text = f'<{effective:.1f}%'
            elif isinstance(raw_limit, dict):
                minimum = raw_limit.get('minPercent', 0)
                limit_text = f'{effective:.1f}% ({minimum:g}–{raw_limit["maxPercent"]:g}%)'
            else:
                limit_text = f'<{effective:g}%'
            reset = reset_description(meter, value, now)
            local_count = local_by_meter[meter][name]
            local_text = f'{compact_tokens(local_count)} tok'
            row.extend([usage_bar(value, color), local_text, limit_text, reset])
        rows.append(row)
    widths = [max(visible_len(headers[i]), *(visible_len(row[i]) for row in rows)) for i in range(len(headers))]
    print(' | '.join(headers[i].ljust(widths[i]) for i in range(len(headers))))
    print('-+-'.join('-' * width for width in widths))
    for row in rows:
        print(' | '.join(row[i] + ' ' * (widths[i] - visible_len(row[i])) for i in range(len(headers))))
    if color:
        print('\x1b[90mGray bar\x1b[0m = account-wide quota used; LOCAL TOKENS = token counters from this machine')
    else:
        print('Gray bar = account-wide quota used; LOCAL TOKENS = token counters from this machine')
    print('LOCAL TOKENS are rolling 5h / 7d totals; they are exact token counts, not a percentage of account quota.')
    active_name = state.get('active')
    active_entry = state.get('accounts', {}).get(active_name, {})
    active_forecasts = row_forecasts.get(active_name, {})
    if active_name and active_entry.get('meters'):
        print('FORECAST', active_name, '(robust median utilization slope)')
        for meter, value in active_entry.get('meters', {}).items():
            trend = active_forecasts.get(meter, {})
            if not trend.get('ready'):
                if trend.get('reason') == 'stale':
                    print(f'  {meter}: stale samples; waiting for a fresh reading')
                else:
                    print(f'  {meter}: warming up ({trend.get("samples", 0)}/{state.get("forecastMinimumSamples", 3)} samples)')
                continue
            if trend.get('rate', 0) <= 0:
                print(f'  {meter}: no measurable increase in recent samples')
                continue
            quality = ('high' if trend.get('confidence', 0) >= 0.75 else
                       'medium' if trend.get('confidence', 0) >= 0.45 else 'low')
            eta_full = (duration_text(trend['etaFull']) if trend['etaFull'] is not None
                        else 'not before reset')
            eta_limit = ('now' if trend['etaLimit'] == 0 else
                         duration_text(trend['etaLimit']) if trend['etaLimit'] is not None
                         else 'not before reset')
            projected = trend.get('projectedAtReset')
            projected_text = f'; projected {projected:.0f}% at reset' if projected is not None else ''
            print(f'  {meter}: +{trend["rate"]:.2f} pp/h; 100% {eta_full}; '
                  f'limit {trend["limit"]:.1f}% {eta_limit}{projected_text}; confidence {quality}')
    for name in names:
        entry = state.get('accounts', {}).get(name, {})
        info = entry.get('errorInfo') or {}
        if info.get('redirectHost'):
            print(f"  {name} redirect: {info['redirectHost']}{info.get('redirectPath', '/')}")
        if entry.get('error') == 'login_required':
            print(f'  {name}: re-login with `cc-account login {name}`')
    if not state.get('available'):
        if state.get('paused'):
            print('Routing paused: no verified account is currently below its quota thresholds.')
        else:
            print('No current quota reading is usable below threshold; no account is selected.')
    if state.get('switchError'):
        print('Selection deferred:', state['switchError'])


def doctor(state, service='unknown', now=None):
    """Explain cached usage and common account-router states without network calls."""
    now = time.time() if now is None else now
    print('Service:', service or 'unknown')
    if not state:
        print('No usage observations yet. Run cc-auto check after logging in.')
        return
    for name in state.get('priority', []):
        entry = state.get('accounts', {}).get(name, {})
        error = entry.get('error')
        if error == 'login_required':
            print(f'{name}: authentication redirect detected; run `cc-account login {name}`.')
        elif error == 'http_429':
            checked = entry.get('checkedAt')
            age = f'last successful quota read {age_text(now - checked)} ago' if checked else 'no successful quota read saved'
            retry = entry.get('nextCheckAt', 0) - now
            wait = f'; next check in {age_text(retry)}' if retry > 0 else ''
            max_age = state.get('maxObservationAgeSeconds', 180)
            fallback_age = state.get('429FallbackMaxAgeSeconds', 900)
            cached_current = bool(entry.get('meters') and checked and now - checked < fallback_age)
            fallback_left = max(0, fallback_age - (now - checked)) if checked else 0
            use = (f'; degraded fallback allowed for at most {duration_text(fallback_left)} with shrinking quota headroom'
                   if cached_current else '; cached quota is too old for auto-selection')
            print(f'{name}: usage API throttled (HTTP 429); {age}{wait}{use}. 429 itself did not return new usage.')
        elif error == 'http_403':
            print(f'{name}: usage API returned HTTP 403; check whether this profile still has access, then re-login only if needed.')
        elif error:
            print(f'{name}: {observation_health(entry, now)}')
        elif entry.get('ok'):
            print(f'{name}: {observation_health(entry, now)}')
        else:
            print(f'{name}: no quota observation yet; run cc-auto check.')
    if not state.get('available'):
        if state.get('paused'):
            print('Routing is paused on the empty hold profile; no cached quota has conservative headroom.')
        else:
            print('No current quota reading is usable; no account is selected.')


def running_profile_processes(directory):
    """Return PIDs only; never expose a process's environment or arguments."""
    found = []
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or int(process.name) == os.getpid():
            continue
        try:
            if process.stat().st_uid != os.getuid():
                continue
            for entry in (process / 'environ').read_bytes().split(b'\0'):
                if entry.startswith(b'CLAUDE_CONFIG_DIR='):
                    configured = os.fsdecode(entry.split(b'=', 1)[1])
                    if configured and Path(configured).resolve() == directory:
                        found.append(int(process.name))
                    break
        except (OSError, ValueError):
            continue
    return found


def remove_profile(root, name):
    """Delete one inactive profile, unlinking rather than following shared data."""
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,63}', name) or name in ('default', 'auto'):
        raise ValueError('Remove a named account profile; default and auto are protected selectors')
    with router_lock(root):
        path = root / 'profiles' / name
        if path.is_symlink() or not path.is_dir():
            raise ValueError('Unknown profile or unexpected profile symlink: ' + name)
        directory = path.resolve()
        config = read_config(root) if (root / 'router.json').exists() else None
        if config:
            pointer = Path(config['fixedConfigDirectory'])
            if pointer.is_symlink() and pointer.resolve() == directory:
                raise ValueError('Account is selected by VS Code/auto. Prioritize another available account, run cc-auto check, then remove it')
        selected = os.environ.get('CLAUDE_CONFIG_DIR')
        if selected and Path(selected).resolve() == directory:
            raise ValueError('Account is selected in this terminal. Run cc-account use default first')
        pids = running_profile_processes(directory)
        if pids:
            raise ValueError('Close processes using this profile before removing it; PIDs: ' + ', '.join(map(str, pids)))
        # A rename detaches the profile from discovery before any deletion. It
        # remains in this private parent until rmtree safely unlinks its symlinks.
        staging = path.with_name('.removed-' + name + '-' + uuid.uuid4().hex)
        path.rename(staging)
        try:
            if config:
                config['priority'] = [entry for entry in config['priority'] if entry != name] or ['default']
                save(root / 'router.json', config)
            state = load(root / 'router-state.json')
            if state:
                state.get('accounts', {}).pop(name, None)
                state['priority'] = [entry for entry in state.get('priority', []) if entry != name]
                save(root / 'router-state.json', state)
        except Exception:
            staging.rename(path)
            raise
        shutil.rmtree(staging)
    print('Removed profile ' + name + ' and its saved login. Shared projects, sessions and settings are preserved.')


def usage_profile(root):
    """Resolve the account used by this Claude turn without recording secrets."""
    config = load(root / 'router.json', {})
    configured = os.environ.get('CLAUDE_CONFIG_DIR') or config.get('fixedConfigDirectory')
    if configured:
        path = Path(configured).expanduser().resolve()
        profiles = (root / 'profiles').resolve()
        if path.parent == profiles and path.name not in ('.cc-auto-hold',):
            return path.name
    return 'default'


def usage_hook(root, event):
    """Persist token counters only; transcript content is never copied."""
    try:
        payload = json.load(sys.stdin)
    except (ValueError, OSError):
        return 0
    session = payload.get('session_id')
    if not isinstance(session, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', session):
        return 0
    data_dir = root / 'usage'
    data_dir.mkdir(mode=0o700, exist_ok=True)
    os.chmod(data_dir, 0o700)
    session_file = data_dir / (session + '.json')
    if event == 'UserPromptSubmit':
        transcript = payload.get('transcript_path')
        offset = None
        if isinstance(transcript, str):
            candidate = Path(transcript).resolve()
            projects = (Path.home() / '.claude' / 'projects').resolve()
            if projects in candidate.parents and candidate.is_file():
                offset = candidate.stat().st_size
        save(session_file, {'profile': usage_profile(root), 'offset': offset})
        return 0
    if event != 'Stop':
        return 0
    session_data = load(session_file, {})
    profile = session_data.get('profile', usage_profile(root))
    offset = session_data.get('offset')
    if not isinstance(offset, int):
        return 0
    transcript = payload.get('transcript_path')
    if not isinstance(transcript, str):
        return 0
    transcript = Path(transcript).resolve()
    projects = (Path.home() / '.claude' / 'projects').resolve()
    if projects not in transcript.parents or not transcript.is_file():
        return 0
    ledger = data_dir / 'events.jsonl'
    with ledger.open('a+', encoding='utf-8') as out:
        os.chmod(ledger, 0o600)
        fcntl.flock(out, fcntl.LOCK_EX)
        out.seek(0)
        seen = set()
        for line in out:
            try:
                seen.add(json.loads(line)['id'])
            except (ValueError, KeyError):
                continue
        try:
            with transcript.open('rb') as source:
                source.seek(min(offset, transcript.stat().st_size))
                for raw_line in source:
                    try:
                        row = json.loads(raw_line.decode('utf-8'))
                        msg = row.get('message') or {}
                        usage = msg.get('usage') or {}
                        event_id = row.get('uuid') or msg.get('id')
                        if row.get('type') != 'assistant' or not event_id or event_id in seen or not usage:
                            continue
                        stamp = row.get('timestamp')
                        when = dt.datetime.fromisoformat(stamp.replace('Z', '+00:00')).astimezone()
                        counters = {key: int(usage.get(key, 0) or 0) for key in (
                            'input_tokens', 'cache_creation_input_tokens', 'cache_read_input_tokens', 'output_tokens')}
                        record = {'id': event_id, 'session': session, 'profile': profile,
                                  'model': msg.get('model'),
                                  'date': when.date().isoformat(), 'timestamp': when.timestamp(), **counters}
                        out.write(json.dumps(record, separators=(',', ':')) + '\n')
                        seen.add(event_id)
                    except (ValueError, TypeError, AttributeError):
                        continue
        except OSError:
            return 0
        out.flush()
        os.fsync(out.fileno())
    session_data['offset'] = transcript.stat().st_size
    save(session_file, session_data)
    return 0


def usage_report(root, date):
    ledger = root / 'usage' / 'events.jsonl'
    if not ledger.exists():
        print('No token usage recorded yet. Claude Code will start recording after the next prompt.')
        return
    totals = {}
    try:
        with ledger.open(encoding='utf-8') as stream:
            for line in stream:
                try:
                    row = json.loads(line)
                    if row.get('date') != date:
                        continue
                    acc = totals.setdefault(row.get('profile', 'unknown'), [0, 0, 0, 0, 0])
                    for i, key in enumerate(('input_tokens', 'cache_creation_input_tokens', 'cache_read_input_tokens', 'output_tokens')):
                        acc[i] += int(row.get(key, 0))
                    acc[4] += 1
                except (ValueError, TypeError):
                    continue
    except OSError:
        print('Could not read local token usage ledger.', file=sys.stderr)
        return
    print('Token usage for', date, '(local time)')
    print('PROFILE      INPUT   CACHE WRITE  CACHE READ  OUTPUT  TOTAL  TURNS')
    print('------------ ------- ------------ ----------- ------- ------ -----')
    for name, values in sorted(totals.items()):
        a, b, c, d, turns = values
        print(f'{name:<12} {a:>7,} {b:>12,} {c:>11,} {d:>7,} {a+b+c+d:>6,} {turns:>5,}')
    if not totals:
        print('No token usage recorded for this date.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['daemon', 'check', 'status', 'doctor', 'priority', 'remove', 'start', 'stop', 'restart', 'logs', 'usage', 'hook'])
    parser.add_argument('names', nargs='*')
    args = parser.parse_args()
    root = root_path()
    if args.action == 'hook':
        return usage_hook(root, args.names[0] if args.names else '')
    if args.action == 'usage':
        date = args.names[0] if args.names else dt.datetime.now().astimezone().date().isoformat()
        try:
            dt.date.fromisoformat(date)
        except ValueError:
            raise ValueError('Usage: cc-auto usage [YYYY-MM-DD]') from None
        usage_report(root, date)
        return 0
    if args.action == 'remove':
        if len(args.names) != 1:
            raise ValueError('Usage: cc-auto remove <account-name>')
        remove_profile(root, args.names[0])
        return 0
    if args.action in ('start', 'stop', 'restart'):
        return subprocess.call(['systemctl', '--user', args.action, SERVICE])
    if args.action == 'logs':
        return subprocess.call(['journalctl', '--user', '-u', SERVICE, '-n', '30', '--no-pager'])
    if args.action in ('status', 'doctor'):
        state = load(root / 'router-state.json')
        service = subprocess.run(['systemctl', '--user', 'is-active', SERVICE], capture_output=True, text=True).stdout.strip()
        if args.action == 'doctor':
            doctor(state, service)
        else:
            display(state)
            print('Service:', service)
        return 0
    if args.action == 'priority':
        with router_lock(root):
            config = read_config(root)
            if not args.names:
                print(' > '.join(config['priority']))
                return 0
            available = profiles(root, load(root / 'manager.json'), dict(config, autoDiscoverProfiles=True))
            if len(args.names) != len(set(args.names)) or any(name not in available for name in args.names):
                raise ValueError('List each existing account at most once; add new profiles with cc-account add first')
            config['priority'] = args.names
            save(root / 'router.json', config)
        print('Priority:', ' > '.join(args.names), '(other profiles follow automatically)')
        return 0
    if args.action == 'check':
        display(tick(root))
        return 0
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    while not STOP.is_set():
        try:
            tick(root)
        except Exception as error:
            # Never log HTTP bodies, credentials, or arbitrary exception messages.
            print('Router check failed:', type(error).__name__, flush=True)
        STOP.wait(5)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError) as error:
        print('cc-auto:', str(error), file=sys.stderr)
        sys.exit(1)
