# Claude Accounts: cài nhanh nhiều account cho CLI và VS Code

Gói dành cho **Linux**, WSL có systemd và VS Code Remote Linux. Cần Python 3.9+
và Claude Code CLI; không cần PowerShell, sudo hay thư viện Python ngoài.
Không hỗ trợ Windows native/macOS trong bản này. Gói chỉ chứa mã công cụ,
không chứa account, token, config cá nhân hay transcript của máy đóng gói.

## Cài đặt

### Debian, Ubuntu và WSL qua APT

Kho APT của dự án cung cấp gói `cc-auto` cho hệ có Python 3.9 trở lên.
Chạy lệnh dưới đây từ tài khoản sẽ sử dụng Claude Code:

```sh
sudo install -d -m 0755 /etc/apt/keyrings
key=$(mktemp)
curl -fsSL https://cuongnguyengit.github.io/cc-auto-apt/apt/cc-auto-archive-keyring.gpg -o "$key" &&
    printf '%s  %s\n' 'ffdf76f4e3e1580b722f97f23ab203170b6d0b1cafdf14124ab06ccc9c7bba80' "$key" | sha256sum -c - &&
    sudo install -m 0644 "$key" /etc/apt/keyrings/cc-auto.gpg &&
    printf '%s\n' 'deb [signed-by=/etc/apt/keyrings/cc-auto.gpg] https://cuongnguyengit.github.io/cc-auto-apt/apt ./' |
    sudo tee /etc/apt/sources.list.d/cc-auto.list >/dev/null
rm -f "$key"
sudo apt update
sudo apt install cc-auto
cc-auto-setup
```

APT cài Python nếu cần. Cài Claude Code CLI riêng theo [hướng dẫn của Anthropic](https://code.claude.com/docs/en/setup).
Lệnh `cc-auto-setup` cấu hình shell, VS Code và systemd cho user hiện tại và
có cùng các tùy chọn như `install.sh` bên dưới. Mở terminal mới sau khi setup.
Sau khi cập nhật gói, chạy lại `cc-auto-setup` để làm mới shell integration và
khởi động lại router. Trước khi gỡ gói, tắt dịch vụ đã bật bằng
`systemctl --user disable --now claude-account-router.service`.

### Cài từ GitHub Releases

Tải `cc-auto-linux-1.0.1.tar.gz` (hoặc `.zip`) từ trang Releases, giải nén và chạy bằng user sử dụng Claude:

```sh
tar -xzf cc-auto-linux-1.0.1.tar.gz     # hoặc: unzip cc-auto-linux-1.0.1.zip
sh claude-accounts/install.sh
```

Mở terminal mới, hoặc nạp ngay trong Bash/Zsh:

```sh
export PATH="$HOME/.local/bin:$PATH"
source "$HOME/.config/claude-accounts/accounts.sh"
```

PowerShell:

```powershell
$env:PATH = "$HOME/.local/bin" + [IO.Path]::PathSeparator + $env:PATH
. "$HOME/.config/claude-accounts/accounts.ps1"
```

Script tạo lệnh `cc-account`, `cc-auto` trong `~/.local/bin`, bổ sung shell profile,
tạo dịch vụ systemd user, bật dịch vụ và cấu hình VS Code local/remote. Cài lại
giữ profile/account, priority, ngưỡng và dữ liệu có sẵn; file được thay đổi có
bản sao tại `~/.claude-accounts/install-backups/`.

Các tùy chọn:

```sh
sh claude-accounts/install.sh --no-vscode     # tự cấu hình ENV cho editor
sh claude-accounts/install.sh --no-service    # chưa bật dịch vụ
sh claude-accounts/install.sh --no-shell      # tự nạp shell integration
sh claude-accounts/install.sh --model sonnet  # quota riêng của model; mặc định opus
```

Không có systemd user hoạt động thì chạy `cc-auto daemon` trong một terminal;
tự chọn chỉ hoạt động khi tiến trình này còn chạy. Dịch vụ systemd user tự chạy
trong phiên đăng nhập. Nếu cần chạy sau khi logout, quản trị viên có thể bật
linger bằng `loginctl enable-linger <user>`; installer không gọi sudo.

## Thêm, chọn và xóa account

`default` là account hiện có trên máy nhận. Nếu máy chưa đăng nhập:

```sh
cc-account login default
```

Thêm bao nhiêu account tùy nhu cầu; mỗi profile đăng nhập một lần bằng trình duyệt:

```sh
cc-account add work
cc-account login work
cc-account add personal
cc-account login personal
cc-auto priority work default personal
cc-auto check
cc-auto status
```

Đăng nhập đúng account trên trang web trước khi xác nhận. Account mới không được
copy token/identity của account cũ. Tên gồm 1–64 ký tự chữ thường, số, `_`, `-`;
`default` và `auto` là tên dành riêng.

```sh
cc-account list                  # danh sách profile
cc-auto priority                 # thứ tự đã cấu hình
cc-auto status                   # thứ tự đầy đủ, account đang dùng và quota
cc-auto usage                    # token từng profile trong ngày hôm nay
cc-auto usage 2026-11-10         # xem một ngày trước đó đã được ghi nhận
cc-auto doctor                   # giải thích trạng thái service, quota cache và lỗi API
cc-auto priority personal work default  # tự đổi thứ tự
cc-account use auto              # terminal theo cùng account với VS Code
claude --continue
cc-account use work              # chọn riêng cho terminal này
claude --resume <session-id>
cc-account use default
cc-auto remove personal          # xóa profile và login đã lưu trên máy
```

Account không liệt kê trong priority được thêm sau cùng theo tên. Profile mới
được tự phát hiện. Xóa giữ nguyên projects/sessions/settings chung; không xóa
tài khoản trên website hay revoke token server. Không được xóa `default`, `auto`,
profile đang được auto chọn hoặc có tiến trình trực tiếp dùng profile. Trước khi
xóa profile đang được chọn, ưu tiên account khác còn quota, `cc-auto check`,
xác nhận `cc-auto status` đã đổi rồi đóng tiến trình còn dùng đường dẫn profile cũ.

Lệnh `use` đổi ENV của terminal nhờ shell function. Chưa nạp shell integration,
hoặc dùng shell khác, có thể khởi chạy trực tiếp:

```sh
cc-account run work --continue
cc-account run auto --resume <session-id>
```

`use` không thay ENV của tiến trình đã chạy. Không chạy hai tiến trình cùng ghi
vào một session. Với manual switch, thoát Claude và resume từ cùng project.

## VS Code

Installer đặt `claudeCode.environmentVariables` trong:

- `~/.config/Code/User/settings.json`
- `~/.vscode-server/data/Machine/settings.json`
- các đường dẫn Code Insiders tương ứng nếu settings đã tồn tại.

Các settings, comments JSONC và ENV khác được giữ nguyên. Chạy
**Developer: Reload Window** một lần sau cài để Claude nhận ENV mới.
Các lần auto đổi account sau đó vẫn dùng cùng đường dẫn:

```json
{
  "claudeCode.environmentVariables": [
    { "name": "CLAUDE_CONFIG_DIR", "value": "/home/YOUR_USER/.claude-vscode" }
  ]
}
```

Nếu dùng VS Code với profile riêng hoặc settings trong workspace ghi đè, thêm
biến này tại settings tương ứng. Đặt đường dẫn tuyệt đối của user trên **máy chạy
extension Claude**; Remote/WSL cần cài gói trên máy Linux đó. `--no-vscode` cho
phép tự làm bước này. Không xóa đường dẫn `.claude-vscode` khi đang dùng Claude.

## Cách chia sẻ và tự chọn

`~/.claude-vscode` là symlink đổi atomically tới profile được chọn. Credentials
và account metadata riêng từng profile; refresh ghi về đúng profile gốc.
`~/.claude-accounts/profiles/<name>` liên kết dữ liệu chung tới `~/.claude`
(hoặc config directory có sẵn nếu đã đặt ENV trước khi cài):

- `projects` (transcript, session, auto memory), `file-history`, `plans`, `tasks`,
  `todos`, `paste-cache`.
- `skills`, `commands`, `agents`, `rules`, `hooks`, `plugins`, `workflows`, `output-styles`.
- `settings.json`, `history.jsonl`; `CLAUDE.md`, `keybindings.json` nếu có lúc thêm profile.

`.credentials.json`, `.claude.json`, policy/account cache và runtime riêng từng
profile. Project trust/MCP/preferences trong `.claude.json` chỉ được seed một lần
khi thêm account; đặt MCP chung ở `.mcp.json` của project khi cần. Dữ liệu máy nhận
được giữ tại chỗ, không được đưa vào gói phát hành.

Dịch vụ kiểm tra usage OAuth thích ứng: account đang dùng mỗi 60/120/300 giây tùy headroom; account dự phòng mỗi 900 giây, giãn cách 45 giây; khi chưa chọn được account, dò một profile mỗi 180 giây. Mặc định chuyển khi quota đạt 95%, account khác phải dưới 90%;
account `default` có thể đặt ngưỡng riêng (hiện dùng 100% cho cả chuyển đi và quay lại). HTTP
429 được backoff theo từng account, tăng dần khi lặp lại, có jitter để các account
không thử lại cùng lúc và luôn tôn trọng `Retry-After`. Với 429, lần đọc thành công
gần nhất vẫn có thể dùng để chọn account trong tối đa 900 giây; lỗi API khác vẫn
được coi là chưa xác định. Router không tạo model request để đo usage. Nếu không
còn quota đủ mới hoặc cache 429 còn hạn, giữ lựa chọn cũ. Cấu hình tại
`~/.claude-accounts/router.json`:
`priority`, `intervalSeconds`, `activeIntervalNearSeconds`,
`activeIntervalMediumSeconds`, `activeIntervalNormalSeconds`,
`candidateIntervalSeconds`, `candidateStaggerSeconds`, `recoveryIntervalSeconds`,
`429FallbackMaxAgeSeconds`, `switchAtPercent`, `returnBelowPercent`,
`accountThresholds`, `maxObservationAgeSeconds`, `model`.

Quota polling is adaptive: the active account uses the near/medium/normal
intervals (default 60/120/300 seconds) based on its short-window quota headroom;
standby accounts are checked every 900 seconds, staggered by 45 seconds. If no
account is selected, one due recovery candidate is checked every 180 seconds.
HTTP 429 backoff remains per account and grows exponentially.
Ví dụ đặt cả hai ngưỡng của account mặc định:

```json
"accountThresholds": {
  "default": { "switchAtPercent": 100, "returnBelowPercent": 100 },
  "work": {
    "meterThresholds": { "five_hour": 50 },
    "pacedMeterThresholds": {
      "seven_day": { "minPercent": 50, "maxPercent": 70, "cycleSeconds": 604800 }
    }
  }
}
```

`meterThresholds` applies the listed quota limits to that account; any unlisted
meter continues to use the global switch or return threshold. Each account can
set paced meters independently. A paced threshold accepts the legacy numeric
form (the maximum, ramping from 0) or an object with `minPercent`, `maxPercent`,
and optional `cycleSeconds`. The live threshold ramps linearly from minimum to
maximum across the reset cycle. For example, `50` to `70` over 604800 seconds
keeps at least 50% weekly headroom available while gradually allowing more as
the week progresses. If reset metadata is missing, the hard maximum remains
the fallback. Per-account settings apply to both switch and return decisions;
unlisted meters use the global threshold.
`cc-auto status` and `cc-auto check` show each meter's live limit and reset
time, even when usage is below its limit. The active profile also shows a
consumption forecast when there are enough recent quota readings.
The usage column includes a 12-cell gray bar for account-wide quota utilization
and a yellow `LOCAL TOKENS` count for this machine's Claude Code usage in the
rolling 5-hour or 7-day window. The local number sums the token counters recorded
in this machine's transcripts. It is a token count, not a percentage of account
quota; the OAuth quota endpoint reports only account-wide utilization.

Forecasting stores up to 64 successful quota samples per meter for one day,
grouped by reset window. It estimates burn with the median pairwise slope over
the latest hour for the 5-hour meter and latest six hours for weekly meters.
At least three fresh samples and measurable movement are required; otherwise
the configured thresholds apply unchanged. When the estimated burn would use
more than the remaining headroom within the safety lead, or projected use would
exceed 100% by reset, cc-auto lowers the effective switch/return threshold. The
cycle-pressure part uses one quarter of projected overrun; combined adjustment
is confidence-weighted and capped at 15 percentage points below the configured
threshold. The default lead is 15 minutes. A 3-minute switch cooldown dampens
preference-driven flips; it is bypassed when the active profile is no longer
eligible or forecast to reach its effective limit within the lead. `cc-auto
check` shows forecast rate, ETA to full, projected usage at reset, and adaptive
limits. Tune `forecastLeadSeconds`, `forecastMaxThresholdReduction`,
`forecastCyclePressureWeight`, `forecastMinimumSamples`,
`forecastMinimumChangePercent`, and `switchCooldownSeconds` in
`~/.claude-accounts/router.json`.

Khi usage API trả HTTP 429, `status` vẫn hiển thị phần trăm từ lần đọc thành công
gần nhất nhưng ghi rõ tuổi dữ liệu và thời điểm thử lại; 429 không chứa số usage
mới. Account có lần đọc thành công còn hạn luôn được ưu tiên. Nếu tất cả account
đều HTTP 429, router có thể dùng snapshot cuối trong tối đa
`429FallbackMaxAgeSeconds` (mặc định 900 giây). Ngưỡng sử dụng giảm tuyến tính
theo tuổi snapshot về 0; router chọn account có khoảng an toàn tốt nhất trên
quota meter chật nhất. Nếu không snapshot nào còn đủ headroom, fixed config
chuyển sang profile rỗng `.cc-auto-hold` và tự chạy lại sau lần đọc quota thành
công. Cache sau các lỗi khác chỉ để hiển thị. `cc-auto doctor` giải thích trạng
thái này mà không gọi API thêm.

Profile mới chưa đăng nhập được phát hiện ngay nhưng có thể tạm báo
`not_logged_in`. Khi login lưu credentials, lần kiểm tra nền tiếp theo nhận ra
ngay (thường trong khoảng 5 giây), không phải chờ backoff của lỗi chưa login.
`cc-auto check` cũng nhận credentials mới ngay; cooldown HTTP 429 vẫn được giữ.
Nếu login lại sau một lỗi API, router nhận ra file credentials đã đổi và thử lại
account đó ngay; khi credentials không đổi, backoff tiếp tục được tôn trọng.

```sh
cc-auto start
cc-auto stop
cc-auto restart
cc-auto logs
cc-auto doctor
cc-account check work
cc-account status
```

ENV API key/token hoặc provider khác có thể ghi đè account. `add`, `use`, `login`
từ chối nếu phát hiện các biến đó; công cụ không tự xóa chúng. `status` giúp kiểm
tra phương thức đăng nhập thực tế.

Đổi account giữa các lượt gửi đã được kiểm tra trên binary extension Claude Code
2.1.293/2.1.295. Lượt đang thực thi giữ credentials đã gửi; account mới áp dụng
ở lượt sau. API usage/refresh và lock là cơ chế nội bộ, có thể cần cập nhật công
cụ nếu Claude Code đổi cách hoạt động. Giao diện có thể giữ metadata trong cache;
reload cửa sổ nếu thông tin hiển thị chưa đổi.

## Tắt và gỡ tích hợp

```sh
systemctl --user disable --now claude-account-router.service
```

Đổi ENV của VS Code về profile mong muốn, xóa block `claude-accounts` trong
`.bashrc`, `.zshrc`, PowerShell profile. Bản sao settings/shell profiles ở
`~/.claude-accounts/install-backups/`. Không xóa dữ liệu chung.

## Kiểm tra gói trước khi cài

```sh
python3 claude-accounts/tests/smoke.py
```

Kiểm tra cài mới/cài lại trong thư mục tạm, JSONC, link dữ liệu chung, thêm/xóa
profile, thứ tự, shell ENV và account router bằng usage giả; không gọi OAuth API,
không dùng tokens và không thay dịch vụ/settings của user đang chạy test.
